package com.project.team.triper.utilities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.project.team.triper.dto.Trip;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Omar on 3/5/2018.
 */

public class DBAdapter {

    private Context context;

    private static MyHelper helper;

    public static final String DATA_BASE_NAME = "triper";
    public static final int DATA_BASE_VERSION = 1;
    public static final String TRIP_TABLE_NAME = "trip";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USER = "user";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_START_POINT = "start_point";
    public static final String COLUMN_END_POINT = "end_point";
    public static final String COLUMN_START_LONGITUDE = "start_longitude";
    public static final String COLUMN_START_LATITUDE = "start_latitude";
    public static final String COLUMN_END_LONGITUDE = "end_longitude";
    public static final String COLUMN_END_LATITUDE = "end_latitude";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_NOTES = "notes";
    public static final String COLUMN_REPEAT = "repeat";
    public static final String COLUMN_DURATION = "duration";
    public static final String COLUMN_AVERAGE_SPEED = "average_speed";
    public static final String COLUMN_MAP_IMAGE_URL = "map_image_url";
    public static final String COLUMN_DISTANCE = "distance";
    public static final String COLUMN_ESTIMATED_TIME = "estimated_time";
    public static final String STATUS_HISTORY = "Done";
    public static final String STATUS_UPCOMING = "Upcoming";
    public static final String STATUS_CANCELLED = "Cancelled";
    public static final String STATUS_CURRENT = "Current";

    public DBAdapter(Context _context) {
        if (helper == null) {
            helper = new MyHelper(_context, DATA_BASE_NAME, null, DATA_BASE_VERSION);
        }
        context = _context;
    }

    private class MyHelper extends SQLiteOpenHelper {

        public MyHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE "
                    + TRIP_TABLE_NAME + " ("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_USER + " VARCHAR(255), "
                    + COLUMN_NAME + " VARCHAR(255), "
                    + COLUMN_DATE + " INTEGER, "
                    + COLUMN_START_POINT + " VARCHAR(255), "
                    + COLUMN_END_POINT + " VARCHAR(255), "
                    + COLUMN_START_LONGITUDE + " REAL, "
                    + COLUMN_START_LATITUDE + " REAL, "
                    + COLUMN_END_LONGITUDE + " REAL, "
                    + COLUMN_END_LATITUDE + " REAL, "
                    + COLUMN_TYPE + " INTEGER, "
                    + COLUMN_STATUS + " VARCHAR(255), "
                    + COLUMN_NOTES + " TEXT, "
                    + COLUMN_REPEAT + " INTEGER, "
                    + COLUMN_DURATION + " REAL, "
                    + COLUMN_AVERAGE_SPEED + " REAL, "
                    + COLUMN_MAP_IMAGE_URL + " TEXT, "
                    + COLUMN_DISTANCE + " TEXT , "
                    + COLUMN_ESTIMATED_TIME + " TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TRIP_TABLE_NAME);
        }
    }

    public void addTrip(Trip trip) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_NAME, trip.getName());
        contentValues.put(COLUMN_USER, trip.getUser());
        contentValues.put(COLUMN_DATE, trip.getDate().getTime());
        contentValues.put(COLUMN_START_POINT, trip.getStartPoint());
        contentValues.put(COLUMN_END_POINT, trip.getEndPoint());
        contentValues.put(COLUMN_START_LONGITUDE, trip.getStartLongitude());
        contentValues.put(COLUMN_START_LATITUDE, trip.getStartLatitude());
        contentValues.put(COLUMN_END_LONGITUDE, trip.getEndLongitude());
        contentValues.put(COLUMN_END_LATITUDE, trip.getEndLatitude());
        contentValues.put(COLUMN_TYPE, trip.isType());
        contentValues.put(COLUMN_STATUS, trip.getStatus());
        contentValues.put(COLUMN_NOTES, trip.getNotes());
        contentValues.put(COLUMN_REPEAT, trip.getRepeat());
        contentValues.put(COLUMN_DURATION, trip.getDuration());
        contentValues.put(COLUMN_AVERAGE_SPEED, trip.getAverageSpeed());
        contentValues.put(COLUMN_MAP_IMAGE_URL, trip.getMapImageUrl());
        contentValues.put(COLUMN_DISTANCE, trip.getDistance());
        contentValues.put(COLUMN_ESTIMATED_TIME, trip.getEstimatedTime());


        db.insert(TRIP_TABLE_NAME, null, contentValues);
    }

    public List<Trip> retrieveUpcomingTripsPerUser(String user) {
        SQLiteDatabase db = helper.getReadableDatabase();
        List<Trip> trips = new ArrayList<>();
        Cursor cursor = db.query(TRIP_TABLE_NAME, new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_USER, COLUMN_DATE
                        , COLUMN_START_POINT, COLUMN_END_POINT, COLUMN_START_LONGITUDE, COLUMN_START_LATITUDE
                        , COLUMN_END_LONGITUDE, COLUMN_END_LATITUDE, COLUMN_TYPE, COLUMN_STATUS, COLUMN_NOTES, COLUMN_REPEAT
                        , COLUMN_DURATION, COLUMN_AVERAGE_SPEED, COLUMN_MAP_IMAGE_URL, COLUMN_DISTANCE, COLUMN_ESTIMATED_TIME}, COLUMN_USER + " = ? AND " + COLUMN_STATUS + " = ?"
                , new String[]{user, STATUS_UPCOMING}, null, null, null);

        while (cursor.moveToNext()) {
            Trip trip = new Trip();
            trip.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            trip.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
            trip.setUser(cursor.getString(cursor.getColumnIndex(COLUMN_USER)));
            trip.setDate(new Date(cursor.getLong(cursor.getColumnIndex(COLUMN_DATE))));
            trip.setStartPoint(cursor.getString(cursor.getColumnIndex(COLUMN_START_POINT)));
            trip.setEndPoint(cursor.getString(cursor.getColumnIndex(COLUMN_END_POINT)));
            trip.setStartLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LONGITUDE)));
            trip.setStartLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LATITUDE)));
            trip.setEndLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LONGITUDE)));
            trip.setEndLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LATITUDE)));
            trip.setType(cursor.getInt(cursor.getColumnIndex(COLUMN_TYPE))>0);
            trip.setStatus(cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)));
            trip.setNotes(cursor.getString(cursor.getColumnIndex(COLUMN_NOTES)));
            trip.setRepeat(cursor.getInt(cursor.getColumnIndex(COLUMN_REPEAT)));
            trip.setDuration(cursor.getFloat(cursor.getColumnIndex(COLUMN_DURATION)));
            trip.setAverageSpeed(cursor.getFloat(cursor.getColumnIndex(COLUMN_AVERAGE_SPEED)));
            trip.setMapImageUrl(cursor.getString(cursor.getColumnIndex(COLUMN_MAP_IMAGE_URL)));
            trip.setDistance(cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE)));
            trip.setEstimatedTime(cursor.getString(cursor.getColumnIndex(COLUMN_ESTIMATED_TIME)));
            trips.add(trip);
        }
        return trips;
    }

    public List<Trip> retrievePastTripsPerUser(String user) {
        SQLiteDatabase db = helper.getReadableDatabase();
        List<Trip> trips = new ArrayList<>();
        Cursor cursor = db.query(TRIP_TABLE_NAME, new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_USER, COLUMN_DATE
                        , COLUMN_START_POINT, COLUMN_END_POINT, COLUMN_START_LONGITUDE, COLUMN_START_LATITUDE
                        , COLUMN_END_LONGITUDE, COLUMN_END_LATITUDE, COLUMN_TYPE, COLUMN_STATUS, COLUMN_NOTES, COLUMN_REPEAT
                        , COLUMN_DURATION, COLUMN_AVERAGE_SPEED, COLUMN_MAP_IMAGE_URL, COLUMN_DISTANCE, COLUMN_ESTIMATED_TIME}, COLUMN_USER + " = ? AND " + COLUMN_STATUS + " IN (?, ?)"
                , new String[]{user, STATUS_HISTORY, STATUS_CANCELLED}, null, null, null);

        while (cursor.moveToNext()) {
            Trip trip = new Trip();
            trip.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            trip.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
            trip.setUser(cursor.getString(cursor.getColumnIndex(COLUMN_USER)));
            trip.setDate(new Date(cursor.getLong(cursor.getColumnIndex(COLUMN_DATE))));
            trip.setStartPoint(cursor.getString(cursor.getColumnIndex(COLUMN_START_POINT)));
            trip.setEndPoint(cursor.getString(cursor.getColumnIndex(COLUMN_END_POINT)));
            trip.setStartLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LONGITUDE)));
            trip.setStartLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LATITUDE)));
            trip.setEndLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LONGITUDE)));
            trip.setEndLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LATITUDE)));
            trip.setType(cursor.getInt(cursor.getColumnIndex(COLUMN_TYPE))>0);
            trip.setStatus(cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)));
            trip.setNotes(cursor.getString(cursor.getColumnIndex(COLUMN_NOTES)));
            trip.setRepeat(cursor.getInt(cursor.getColumnIndex(COLUMN_REPEAT)));
            trip.setDuration(cursor.getFloat(cursor.getColumnIndex(COLUMN_DURATION)));
            trip.setAverageSpeed(cursor.getFloat(cursor.getColumnIndex(COLUMN_AVERAGE_SPEED)));
            trip.setMapImageUrl(cursor.getString(cursor.getColumnIndex(COLUMN_MAP_IMAGE_URL)));
            trip.setDistance(cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE)));
            trip.setEstimatedTime(cursor.getString(cursor.getColumnIndex(COLUMN_ESTIMATED_TIME)));
            trips.add(trip);
        }
        return trips;
    }

    public List<Trip> retrieveAllTripsPerUser(String user) {
        SQLiteDatabase db = helper.getReadableDatabase();
        List<Trip> trips = new ArrayList<>();
        Cursor cursor = db.query(TRIP_TABLE_NAME, new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_USER, COLUMN_DATE
                        , COLUMN_START_POINT, COLUMN_END_POINT, COLUMN_START_LONGITUDE, COLUMN_START_LATITUDE
                        , COLUMN_END_LONGITUDE, COLUMN_END_LATITUDE, COLUMN_TYPE, COLUMN_STATUS, COLUMN_NOTES, COLUMN_REPEAT
                        , COLUMN_DURATION, COLUMN_AVERAGE_SPEED, COLUMN_MAP_IMAGE_URL, COLUMN_DISTANCE, COLUMN_ESTIMATED_TIME}, COLUMN_USER + " = ?"
                , new String[]{user}, null, null, null);

        while (cursor.moveToNext()) {
            Trip trip = new Trip();
            trip.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            trip.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
            trip.setUser(cursor.getString(cursor.getColumnIndex(COLUMN_USER)));
            trip.setDate(new Date(cursor.getLong(cursor.getColumnIndex(COLUMN_DATE))));
            trip.setStartPoint(cursor.getString(cursor.getColumnIndex(COLUMN_START_POINT)));
            trip.setEndPoint(cursor.getString(cursor.getColumnIndex(COLUMN_END_POINT)));
            trip.setStartLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LONGITUDE)));
            trip.setStartLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LATITUDE)));
            trip.setEndLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LONGITUDE)));
            trip.setEndLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LATITUDE)));
            trip.setType(cursor.getInt(cursor.getColumnIndex(COLUMN_TYPE))>0);
            trip.setStatus(cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)));
            trip.setNotes(cursor.getString(cursor.getColumnIndex(COLUMN_NOTES)));
            trip.setRepeat(cursor.getInt(cursor.getColumnIndex(COLUMN_REPEAT)));
            trip.setDuration(cursor.getFloat(cursor.getColumnIndex(COLUMN_DURATION)));
            trip.setAverageSpeed(cursor.getFloat(cursor.getColumnIndex(COLUMN_AVERAGE_SPEED)));
            trip.setMapImageUrl(cursor.getString(cursor.getColumnIndex(COLUMN_MAP_IMAGE_URL)));
            trip.setDistance(cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE)));
            trip.setEstimatedTime(cursor.getString(cursor.getColumnIndex(COLUMN_ESTIMATED_TIME)));
            trips.add(trip);
        }
        return trips;
    }

    public boolean updateTrip(Trip trip) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_NAME, trip.getName());
        contentValues.put(COLUMN_USER, trip.getUser());
        contentValues.put(COLUMN_DATE, trip.getDate().getTime());
        contentValues.put(COLUMN_START_POINT, trip.getStartPoint());
        contentValues.put(COLUMN_END_POINT, trip.getEndPoint());
        contentValues.put(COLUMN_START_LONGITUDE, trip.getStartLongitude());
        contentValues.put(COLUMN_START_LATITUDE, trip.getStartLatitude());
        contentValues.put(COLUMN_END_LONGITUDE, trip.getEndLongitude());
        contentValues.put(COLUMN_END_LATITUDE, trip.getEndLatitude());
        contentValues.put(COLUMN_TYPE, trip.isType());
        contentValues.put(COLUMN_STATUS, trip.getStatus());
        contentValues.put(COLUMN_NOTES, trip.getNotes());
        contentValues.put(COLUMN_REPEAT, trip.getRepeat());
        contentValues.put(COLUMN_DURATION, trip.getDuration());
        contentValues.put(COLUMN_AVERAGE_SPEED, trip.getAverageSpeed());
        contentValues.put(COLUMN_MAP_IMAGE_URL, trip.getMapImageUrl());
        contentValues.put(COLUMN_DISTANCE, trip.getDistance());
        contentValues.put(COLUMN_ESTIMATED_TIME, trip.getEstimatedTime());



        return db.update(TRIP_TABLE_NAME, contentValues, COLUMN_ID + " = ?"
                , new String[]{String.valueOf(trip.getId())}) > 0;
    }

    public boolean deleteTrip(Trip trip) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete(TRIP_TABLE_NAME, COLUMN_ID + " = ?", new String[]{String.valueOf(trip.getId())}) > 0;
    }

    public Trip retrieveTripById(int id) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Trip trip = null;
        Cursor cursor = db.query(TRIP_TABLE_NAME, new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_USER, COLUMN_DATE
                        , COLUMN_START_POINT, COLUMN_END_POINT, COLUMN_START_LONGITUDE, COLUMN_START_LATITUDE
                        , COLUMN_END_LONGITUDE, COLUMN_END_LATITUDE, COLUMN_TYPE, COLUMN_STATUS, COLUMN_NOTES, COLUMN_REPEAT
                        , COLUMN_DURATION, COLUMN_AVERAGE_SPEED, COLUMN_MAP_IMAGE_URL, COLUMN_DISTANCE, COLUMN_ESTIMATED_TIME}, COLUMN_ID + " = ?"
                , new String[]{String.valueOf(id)}, null, null, null);

        if (cursor.moveToFirst()) {
            trip = new Trip();
            trip.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            trip.setName(cursor.getString(cursor.getColumnIndex(COLUMN_NAME)));
            trip.setUser(cursor.getString(cursor.getColumnIndex(COLUMN_USER)));
            trip.setDate(new Date(cursor.getLong(cursor.getColumnIndex(COLUMN_DATE))));
            trip.setStartPoint(cursor.getString(cursor.getColumnIndex(COLUMN_START_POINT)));
            trip.setEndPoint(cursor.getString(cursor.getColumnIndex(COLUMN_END_POINT)));
            trip.setStartLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LONGITUDE)));
            trip.setStartLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_START_LATITUDE)));
            trip.setEndLongitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LONGITUDE)));
            trip.setEndLatitude(cursor.getDouble(cursor.getColumnIndex(COLUMN_END_LATITUDE)));
            trip.setType(cursor.getInt(cursor.getColumnIndex(COLUMN_TYPE))>0);
            trip.setStatus(cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)));
            trip.setNotes(cursor.getString(cursor.getColumnIndex(COLUMN_NOTES)));
            trip.setRepeat(cursor.getInt(cursor.getColumnIndex(COLUMN_REPEAT)));
            trip.setDuration(cursor.getFloat(cursor.getColumnIndex(COLUMN_DURATION)));
            trip.setAverageSpeed(cursor.getFloat(cursor.getColumnIndex(COLUMN_AVERAGE_SPEED)));
            trip.setMapImageUrl(cursor.getString(cursor.getColumnIndex(COLUMN_MAP_IMAGE_URL)));
            trip.setDistance(cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE)));
            trip.setEstimatedTime(cursor.getString(cursor.getColumnIndex(COLUMN_ESTIMATED_TIME)));
        }
        return trip;
    }

    public int retrieveLastEntry() {
        SQLiteDatabase db = helper.getReadableDatabase();
        int lastTripId = 0;
//        Cursor cursor = db.rawQuery("SELECT MAX(" + COLUMN_ID + ") FROM " + TRIP_TABLE_NAME, null);
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_ID + " FROM " + TRIP_TABLE_NAME, null);
//        Cursor cursor = db.query(TRIP_TABLE_NAME, new String[]{COLUMN_ID}, COLUMN_ID + " = ?", new String[]{"MAX(" + COLUMN_ID + ")"}, null, null, null);
        if (cursor.moveToLast()) {
            lastTripId = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
        }
        return lastTripId;
    }
}
