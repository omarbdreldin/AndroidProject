package com.project.team.triper.adaptor;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.fragments.HistoryDetailDialogFragment;
import com.project.team.triper.utilities.DBAdapter;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by 3alilio on 3/14/2018.
 */

public class HistoryTripAdapter extends RecyclerView.Adapter<HistoryTripAdapter.MyViewHolder> {


    private Context mContext;
    private List<Trip> tripList;
    Trip t_temp;

    public HistoryTripAdapter(Context mContext, List<Trip> tripList) {

        this.mContext = mContext;
        this.tripList = tripList;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_card,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
            t_temp = tripList.get(position);
            holder.getTv_tripname().setText(t_temp.getName());


        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM");

        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");

        String element_date =sdf.format(t_temp.getDate());
        String element_time = timeFormat.format(t_temp.getDate());

        holder.getTv_tripday().setText(element_date);
        holder.getTv_triphour().setText(element_time);

        holder.getTv_tripstart().setText(t_temp.getStartPoint());
        holder.getTv_tripend().setText(t_temp.getEndPoint());
        holder.getTv_tripstatus().setText(t_temp.getStatus());

        if (t_temp.isType()) {
            holder.getTv_triptype().setText("Round Trip");
        } else {
            holder.getTv_triptype().setText("One Direction");
        }



            holder.getCardLayout().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(mContext,"CLICKED ON WHOLE", Toast.LENGTH_LONG).show();
                    HistoryDetailDialogFragment fh = HistoryDetailDialogFragment.newInstance(tripList.get(position));
                    fh.show(((MainActivity) mContext).getSupportFragmentManager()
                            .beginTransaction().show(fh).addToBackStack(null), "detailDiag");
                }
            });
    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }

    public void remove(int swipedPosition) {
        tripList.remove(swipedPosition);
        notifyDataSetChanged();
    }

    public void add(int swipedPosition, Trip trip) {
        tripList.add(swipedPosition, trip);
        notifyDataSetChanged();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView tv_tripname,tv_tripstart,tv_tripend,tv_tripday,tv_triphour,tv_triptype,tv_tripstatus;

        RelativeLayout cardLayout;

        public MyViewHolder(View itemView) {
            super(itemView);

            tv_tripname = itemView.findViewById(R.id.tv_tripName);
            tv_tripstart = itemView.findViewById(R.id.tv_start);
            tv_tripend = itemView.findViewById(R.id.tv_end);
            tv_tripday = itemView.findViewById(R.id.tv_day);
            tv_triphour = itemView.findViewById(R.id.tv_hour);
            tv_triptype = itemView.findViewById(R.id.tv_type);
            tv_tripstatus = itemView.findViewById(R.id.tv_tripStatus);

            cardLayout = itemView.findViewById(R.id.cardView);
        }

        public TextView getTv_tripname() {
            return tv_tripname;
        }

        public TextView getTv_tripstart() {
            return tv_tripstart;
        }

        public TextView getTv_tripend() {
            return tv_tripend;
        }

        public TextView getTv_tripday() {
            return tv_tripday;
        }

        public TextView getTv_triphour() {
            return tv_triphour;
        }

        public TextView getTv_triptype() {
            return tv_triptype;
        }

        public TextView getTv_tripstatus() {
            return tv_tripstatus;
        }

        public RelativeLayout getCardLayout() {
            return cardLayout;
        }
    }

}








