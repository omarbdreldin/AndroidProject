package com.project.team.triper.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.project.team.triper.R;
import com.project.team.triper.dto.User;
import com.project.team.triper.utilities.Utilities;

public class SignupActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    EditText et_email,et_password,et_confirm_password,et_userName;
    Button btn_signup;
    String email,password,user_name,confirmpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        mAuth = FirebaseAuth.getInstance();

        btn_signup = (Button) findViewById(R.id.btn_register);
        et_email = (EditText) findViewById(R.id.et_email);
        et_password =   (EditText) findViewById(R.id.et_password);
        et_userName = (EditText) findViewById(R.id.et_userName);
        et_confirm_password = (EditText) findViewById(R.id.et_confirmpassword);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = et_email.getText().toString();
                password = et_password.getText().toString();
                user_name = et_userName.getText().toString();
                confirmpassword = et_confirm_password.getText().toString();

                if(!Utilities.isNetworkAvailable(SignupActivity.this))
                {
                    Toast.makeText(SignupActivity.this,"Please Connect Your internet and try again",Toast.LENGTH_LONG).show();
                }
                else if(user_name.trim().length()==0 | user_name.isEmpty())
                {
                    et_userName.setError("Enter username");
                }
                else if (email.isEmpty()) {
                    et_email.setError("Enter Email");
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    et_email.setError("Email Not Formatted");
                } else if (password.isEmpty()|| password.length()<7) {
                    et_password.setError("Enter Password not less than 7 characters");
                }
                else if(!password.equals(confirmpassword)) {
                    et_confirm_password.setError("Password Doesn't Match");
                }
                else {
                    Utilities.showLoadingDialog(SignupActivity.this);
                    mAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(SignupActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        FirebaseUser user = mAuth.getCurrentUser();

                                        Intent i = new Intent(SignupActivity.this,MainActivity.class);
                                        User u = new User();
                                        u.setId(user.getUid());
                                        u.setMail(email);
                                        u.setName(user_name);
                                        //i.putExtra("user",u);
                                        SharedPreferences settings = getSharedPreferences("userdata",MODE_PRIVATE);
                                        SharedPreferences.Editor editor = settings.edit();
                                        editor.putString("userid",user.getUid());
                                        editor.putString("usermail",user.getEmail());
                                        editor.putString("username",user_name);
                                        editor.putInt("Flag",0);
                                        editor.commit();

                                        //add user in firebase
                                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                                        DatabaseReference myRef = database.getReference(user.getUid());
                                        myRef.child("personalData").setValue(u);

                                        startActivity(i);
                                        Utilities.dismissDialog();
                                        finish();
                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Toast.makeText(SignupActivity.this, "Authentication Failed.",
                                                Toast.LENGTH_SHORT).show();
                                        Utilities.dismissDialog();
                                    }

                                }
                            });
                }
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
    }
}
