package com.project.team.triper.fragments;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TimePicker;
import android.app.DatePickerDialog.OnDateSetListener;

import com.project.team.triper.R;


public class TimeFragment extends DialogFragment {
    TimePickerDialog.OnTimeSetListener ontimeSet;
    private int Hour, Minute;
    private TimePicker timePicker;




    public TimeFragment() {
        // Required empty public constructor
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        View v = LayoutInflater.from(getActivity())
                .inflate(R.layout.fragment_time, null);

        timePicker = (TimePicker) v.findViewById(R.id.timePicker);
        return new TimePickerDialog(getActivity(), ontimeSet, Hour, Minute,
                DateFormat.is24HourFormat(getActivity()));
    }
    public void setCallBack(TimePickerDialog.OnTimeSetListener ontime) {
        ontimeSet = ontime;
    }

    @Override
    public void setArguments(Bundle args) {
        super.setArguments(args);
        Hour = args.getInt("Hour");
        Minute = args.getInt("Minute");

    }
}
