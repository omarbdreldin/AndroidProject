package com.project.team.triper.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.project.team.triper.R;
import com.project.team.triper.dto.Trip;

import java.text.SimpleDateFormat;

/**
 * Created by 3alilio on 3/17/2018.
 */

public class HistoryDetailDialogFragment extends DialogFragment {
    Trip trip;
    TextView tv_triptitle,tv_tripstartpoint,tv_tripEndpoinr,tv_tripDate,tv_tripTime,tv_tripstatus,tv_tripdistance,tv_avgSpeed;
    ImageView img_route;
    ImageButton img_backarrow;

    public static HistoryDetailDialogFragment newInstance(Trip _trip) {

        HistoryDetailDialogFragment f = new HistoryDetailDialogFragment();

        Bundle args = new Bundle();
        args.putSerializable("trip", _trip);
        f.setArguments(args);

        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_TITLE, 0);

        trip = (Trip) getArguments().getSerializable("trip");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_history_detail_dialogue, container, false);

        tv_triptitle = view.findViewById(R.id.tv_tripTitle);
        tv_tripstartpoint=view.findViewById(R.id.tv_startPoint);
        tv_tripEndpoinr=view.findViewById(R.id.tv_EndPoint);
        tv_tripDate=view.findViewById(R.id.tv_tripDate);
        tv_tripTime=view.findViewById(R.id.tv_triptime);
        tv_tripstatus=view.findViewById(R.id.tv_tripStatushistory);
        tv_tripdistance=view.findViewById(R.id.tv_distance);
        tv_avgSpeed=view.findViewById(R.id.tv_avgspeed);

        img_backarrow = view.findViewById(R.id.img_backarrow);
        img_backarrow.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        img_route = view.findViewById(R.id.img_route);

        Glide.with(getActivity()).load(trip.getMapImageUrl()).into(img_route);

        tv_triptitle.setText(trip.getName());
        tv_avgSpeed.setText(trip.getEstimatedTime());

        tv_tripstartpoint.setText(trip.getStartPoint());
        tv_tripEndpoinr.setText(trip.getEndPoint());

        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM");
        String element_date =sdf.format(trip.getDate());
        SimpleDateFormat sdf2 = new SimpleDateFormat("hh:mm:ss a");

        String element_time = sdf2.format(trip.getDate());

        tv_tripDate.setText(element_date);
        tv_tripTime.setText(element_time);
        tv_tripstatus.setText(trip.getStatus());

        tv_tripdistance.setText(trip.getDistance());
        System.out.println(trip.getDistance() + trip.getEstimatedTime()+trip.getMapImageUrl());

        return view;
    }



    @Override
    public void onStart() {
        super.onStart();

        setControlsListeners();
    }

    @Override
    public void onResume() {
        super.onResume();

        ViewGroup.LayoutParams params = getDialog().getWindow().getAttributes();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.MATCH_PARENT;
        getDialog().getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
    }

    private void setControlsListeners() {
        img_backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });
    }
}


