package com.project.team.triper.utilities;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.MyFloatingViewService;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.fragments.UpcomingTripsFragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by 3alilio on 3/5/2018.
 */

public class Utilities {

    private static ProgressDialog progressDialog;
    private static boolean showYesNoDialogReturn;
    public static final String STATIC_MAPS_API_KEY = "AIzaSyD5hVRygiuXSa6TYK80USXwgJ60gJPa9i4";
    public static final String DIRECTIONS_API_KEY = "AIzaSyAVs5cfRHtpbsZcERIFYfnBOZRPq7LPkfo";

    private static FirebaseDatabase database = FirebaseDatabase.getInstance();
    private static DatabaseReference myRef ;
    private static Trip trip_temp = null;
    private static HashMap<Integer,Trip> allTrips;


    public static void setAlarm(Context context, Trip trip, User user) {
        //getting the alarm manager
        final AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        //creating a new intent specifying the broadcast receiver
        final Intent i = new Intent(context, MyAlarm.class);

        i.putExtra("tripId", trip.getId());
        i.putExtra("userId", user.getId());

        final PendingIntent pi = PendingIntent.getBroadcast(context
                , new DBAdapter(context).retrieveLastEntry(), i
                , PendingIntent.FLAG_UPDATE_CURRENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trip.getDate().getTime(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, trip.getDate().getTime(), pi);
        }
    }

    public static void AddtripFB(User u, Trip t)
    {
        myRef = database.getReference(u.getId());
        myRef.child("Trips").child("&"+t.getId()).setValue(t);
    }

    public static void DeleteTripFB(User u, Trip t)
    {
        myRef = database.getReference(u.getId());
        myRef.child("Trips").child("&"+t.getId()).setValue(null);
    }

    public static Trip GetTrip(User u) {
        myRef = database.getReference(u.getId());
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                trip_temp = (Trip) dataSnapshot.child("trips").getValue();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                trip_temp=null;
            }
        });
        return trip_temp;
    }

    public static HashMap<Integer,Trip> GetAllTrips(User u) {
        myRef = database.getReference(u.getId());
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                allTrips = (HashMap<Integer, Trip>) dataSnapshot.child("trips").getValue();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                allTrips=null;
            }
        });
        return allTrips;
    }

    public static void showLoadingDialog(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
    }

    public static void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static boolean showYesNoDialog(Context context, String messege) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        showYesNoDialogReturn = true;
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        showYesNoDialogReturn = false;
                        dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(messege).setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
        return showYesNoDialogReturn;
    }

    public static void cancelAlarm(Context context, Trip trip) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent cancelServiceIntent = new Intent(context, MyAlarm.class);
        PendingIntent cancelServicePendingIntent = PendingIntent.getBroadcast(context
                , trip.getId(), cancelServiceIntent
                , PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(cancelServicePendingIntent);
    }

    public static void startTrip(Context context, Trip trip, User user) {
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + trip.getEndLatitude()
                + "," + trip.getEndLongitude());
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        mapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(mapIntent);
        Intent floatIntent = new Intent(context, MyFloatingViewService.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("trip", trip);
        bundle.putSerializable("user", user);
        floatIntent.putExtras(bundle);
        floatIntent.putExtra("trip", trip);
        context.startService(floatIntent);
        checkTypeAndSetRoundTrip(context, trip, user);
        trip.setStatus(DBAdapter.STATUS_CURRENT);
        new DBAdapter(context).updateTrip(trip);
    }

    private static void checkTypeAndSetRoundTrip(final Context context, Trip trip, final User user) {
        if (trip.isType()) {

            final Trip tempTrip = new Trip();
            tempTrip.setName(trip.getName());
            tempTrip.setStatus(DBAdapter.STATUS_UPCOMING);
            tempTrip.setMapImageUrl(trip.getMapImageUrl());
            tempTrip.setRepeat(trip.getRepeat());
            tempTrip.setType(trip.isType());
            tempTrip.setEndLatitude(trip.getStartLatitude());
            tempTrip.setEndLongitude(trip.getStartLongitude());
            tempTrip.setStartLatitude(trip.getEndLatitude());
            tempTrip.setStartLongitude(trip.getEndLongitude());
            tempTrip.setEndPoint(trip.getStartPoint());
            tempTrip.setStartPoint(trip.getEndPoint());
            tempTrip.setUser(trip.getUser());
            tempTrip.setDate(trip.getDate());

//            trip.setUrl(context);
            tempTrip.setNotes(null);
            tempTrip.setName(trip.getName() + " (Back Trip)");
            tempTrip.setType(false);
            tempTrip.setRepeat(0);
            tempTrip.setStatus(DBAdapter.STATUS_UPCOMING);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(tempTrip.getDate());
            calendar.add(Calendar.HOUR, 1);
            tempTrip.setDate(new Date(calendar.getTimeInMillis()));

            new AsyncTask<Trip, Void, Void>() {

                @Override
                protected Void doInBackground(Trip... trips) {
                    final Trip trip = trips[0];
                    String polyLinesRequest = "https://maps.googleapis.com/maps/api/directions/json?origin="
                            + trip.getStartLatitude() + "," + trip.getStartLongitude()
                            + "&destination=" + trip.getEndLatitude() + "," + trip.getEndLongitude()
                            + "&key=" + Utilities.DIRECTIONS_API_KEY; System.out.println(polyLinesRequest);
                    RequestQueue queue = Volley.newRequestQueue(context);
                    JsonObjectRequest jsonRequest = new JsonObjectRequest(polyLinesRequest, new JSONObject(), new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String encodedPolyLines = response.getJSONArray("routes").getJSONObject(0)
                                        .getJSONObject("overview_polyline").getString("points");

                                String mapImageUrl = "https://maps.googleapis.com/maps/api/staticmap?size=400x200"

                                        + "&path=color:0xff0000ff|weight:5|enc:" + encodedPolyLines
                                        + "&key=" + Utilities.STATIC_MAPS_API_KEY;

                                String distance = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                        getJSONObject(0).getJSONObject("distance").getString("text");

                                String estimatedTime = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                        getJSONObject(0).getJSONObject("duration").getString("text");

                                trip.setMapImageUrl(mapImageUrl);
                                trip.setDistance(distance);
                                trip.setEstimatedTime(estimatedTime);

//                                        System.out.println(Trip.this.distance + " " + Trip.this.estimatedTime + "" + mapImageUrl);

                                new DBAdapter(context).addTrip(trip);
                                trip.setId(new DBAdapter(context).retrieveLastEntry());
                                setAlarm(context, trip, user);
                                AddtripFB(user, trip);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });

                    queue.add(jsonRequest);
                    return null;
                }
            }.execute(tempTrip);
        }
    }

    public static void checkAndSetRepeat(Trip trip, Context context, User user) {
        Calendar tempCalendar = Calendar.getInstance();
        tempCalendar.setTime(trip.getDate());

        int repeat = trip.getRepeat();

        if (repeat != 0) {
            Trip tempTrip = new Trip();
            tempTrip.setName(trip.getName());
            tempTrip.setStatus(DBAdapter.STATUS_UPCOMING);
            tempTrip.setMapImageUrl(trip.getMapImageUrl());
            tempTrip.setRepeat(trip.getRepeat());
            tempTrip.setType(trip.isType());
            tempTrip.setEndLatitude(trip.getEndLatitude());
            tempTrip.setEndLongitude(trip.getEndLongitude());
            tempTrip.setStartLatitude(trip.getStartLatitude());
            tempTrip.setStartLongitude(trip.getStartLongitude());
            tempTrip.setEndPoint(trip.getEndPoint());
            tempTrip.setStartPoint(trip.getStartPoint());
            tempTrip.setEstimatedTime(trip.getEstimatedTime());
            tempTrip.setDistance(trip.getDistance());
            tempTrip.setUser(trip.getUser());

            switch (repeat) {
                case 1: tempCalendar.add(Calendar.DATE, 1); break;
                case 2: tempCalendar.add(Calendar.DATE, 7); break;
                case 3: tempCalendar.add(Calendar.DATE, 30); break;
            }

            tempTrip.setDate(new Date(tempCalendar.getTimeInMillis()));
            DBAdapter dbAdapter = new DBAdapter(context);
            dbAdapter.addTrip(tempTrip);
            AddtripFB(user, tempTrip);
            tempTrip.setId(dbAdapter.retrieveLastEntry());
            setAlarm(context, tempTrip, user);
        }
    }
}
