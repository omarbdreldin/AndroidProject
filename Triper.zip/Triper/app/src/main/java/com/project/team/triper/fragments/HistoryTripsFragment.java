package com.project.team.triper.fragments;


import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.adaptor.HistoryTripAdapter;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HistoryTripsFragment extends Fragment {

    RecyclerView hitoryTripRecyclerView;
    FrameLayout historymainlayout;
    ArrayList<Trip> historyTripList;
    HistoryTripAdapter historyAdapter;

    @Override
    public void onStart() {
        super.onStart();

        historyTripList = (ArrayList<Trip>) new DBAdapter(getContext())
                .retrievePastTripsPerUser(((MainActivity) getActivity()).getMail());
        hitoryTripRecyclerView.setHasFixedSize(true);
        if(historyTripList.size()>0)
        {
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
            hitoryTripRecyclerView.setLayoutManager(layoutManager);
            historyAdapter = new HistoryTripAdapter(getContext(),historyTripList);
            hitoryTripRecyclerView.setAdapter(historyAdapter);
        }
        else {
            TextView mytext = new TextView(getContext());
            mytext.setGravity(View.TEXT_ALIGNMENT_GRAVITY);
            mytext.setText("No History Trips To show");
            historymainlayout.addView(mytext);
        }
    }




    public HistoryTripsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View history_fragment_view = inflater.inflate(R.layout.fragment_history_trips, container, false);
        hitoryTripRecyclerView =history_fragment_view.findViewById(R.id.recyclerview_history);
        historymainlayout = history_fragment_view.findViewById(R.id.frame_history);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0
                , ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder
                    , RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
                final int swipedPosition = viewHolder.getAdapterPosition();
                final Trip trip = historyTripList.get(swipedPosition);

                Snackbar.make(hitoryTripRecyclerView, "Deleted", Snackbar.LENGTH_LONG)
                        .setAction("Undo", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                historyAdapter.add(swipedPosition, trip);
                                hitoryTripRecyclerView.scrollToPosition(swipedPosition);
                            }

                        }).addCallback(new Snackbar.Callback() {
                    @Override
                    public void onDismissed(Snackbar transientBottomBar, int event) {
                        super.onDismissed(transientBottomBar, event);
                        if (event != DISMISS_EVENT_ACTION) {
                            new DBAdapter(getContext()).deleteTrip(trip);
                            User u = ((MainActivity) getActivity()).getUser_home();
                            Utilities.DeleteTripFB(u, trip);
                        }
                    }
                }).show();
                historyAdapter.remove(swipedPosition);

            }

        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(hitoryTripRecyclerView);






        return history_fragment_view;

    }

}
