package com.project.team.triper.fragments;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.util.Util;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.adaptor.HistoryTripAdapter;
import com.project.team.triper.adaptor.TripDataAdapter;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpcomingTripsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ArrayList<Trip> tripList;
    private TripDataAdapter adapter;
    private FrameLayout upcomingLayout;
    Context context;
    User user;

    public UpcomingTripsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_trips, container, false);
        recyclerView = view.findViewById(R.id.upcomingTripsView);
        upcomingLayout = view.findViewById(R.id.upcomingLayout);
        user = ((MainActivity) getActivity()).getUser_home();

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0
                , ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder
                    , RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
                final int swipedPosition = viewHolder.getAdapterPosition();
                final Trip trip = tripList.get(swipedPosition);

                Snackbar.make(recyclerView, "Deleted", Snackbar.LENGTH_LONG)
                        .setAction("Undo", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                adapter.add(swipedPosition, trip);
                                recyclerView.scrollToPosition(swipedPosition);
                            }

                        }).addCallback(new Snackbar.Callback() {
                    @Override
                    public void onDismissed(Snackbar transientBottomBar, int event) {
                        super.onDismissed(transientBottomBar, event);
                        if (event != DISMISS_EVENT_ACTION) {
                            try {
                                Utilities.cancelAlarm(context, trip);
                                Utilities.DeleteTripFB(user, trip);
                                new DBAdapter(context).deleteTrip(trip);
                            } catch (Exception e) {
                            }
                        }
                    }
                }).show();
                adapter.remove(swipedPosition);

            }

        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    public void onStart() {
        super.onStart();

        retrieveUpcomingTrips();
        recyclerView.setHasFixedSize(true);
        if (tripList.size() > 0) {
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
            recyclerView.setLayoutManager(layoutManager);
            adapter = new TripDataAdapter(tripList, getContext());
            recyclerView.setAdapter(adapter);
        } else {
            TextView mytext = new TextView(getContext());
            mytext.setGravity(View.TEXT_ALIGNMENT_GRAVITY);
            mytext.setText("No Upcoming Trips To Show");
            upcomingLayout.addView(mytext);
        }
        adapter = new TripDataAdapter(tripList, getContext());
        recyclerView.setAdapter(adapter);
    }

    public void retrieveUpcomingTrips() {
        tripList = (ArrayList<Trip>) new DBAdapter(getContext())
                .retrieveUpcomingTripsPerUser(((MainActivity) getActivity()).getMail());
    }

    @Override
    public void onResume() {
        super.onResume();
        if (tripList.size() != new DBAdapter(getContext()).retrieveUpcomingTripsPerUser(user.getMail()).size()) {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    public void setContext(Context context) {
        this.context = context;
    }
}
