package com.project.team.triper.fragments;


import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.project.team.triper.R;
import com.project.team.triper.interfaces.NoteDiagFragCommunicator;

/**
 * A simple {@link Fragment} subclass.
 */
public class RepetitionDialogFragment extends DialogFragment {

    int tripRepetition;
    NoteDiagFragCommunicator noteDiagFragCommunicator;
    RadioGroup radioGroup;
    RadioButton noneRadio;
    RadioButton dailyRadio;
    RadioButton weeklyRadio;
    RadioButton monthlyRadio;
    Button selectButton;

    static RepetitionDialogFragment newInstance(int _tripRepetition
            , NoteDiagFragCommunicator _noteDiagFragCommunicator) {

        RepetitionDialogFragment f = new RepetitionDialogFragment();

        Bundle args = new Bundle();
        args.putInt("tripRepetition", _tripRepetition);
        args.putSerializable("parentFrag",_noteDiagFragCommunicator);
        f.setArguments(args);

        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tripRepetition = getArguments().getInt("tripRepetition");
        noteDiagFragCommunicator = (NoteDiagFragCommunicator) getArguments().getSerializable("parentFrag");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_repetition_dialog, container, false);
        radioGroup = view.findViewById(R.id.radioGroup);
        noneRadio = view.findViewById(R.id.noneRadio);
        dailyRadio = view.findViewById(R.id.dailyRadio);
        weeklyRadio = view.findViewById(R.id.weeklyRadio);
        monthlyRadio = view.findViewById(R.id.monthlyRadio);
        selectButton = view.findViewById(R.id.selectButton);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        switch (tripRepetition) {
            case 0: radioGroup.check(R.id.noneRadio); break;
            case 1: radioGroup.check(R.id.dailyRadio); break;
            case 2: radioGroup.check(R.id.weeklyRadio); break;
            case 3: radioGroup.check(R.id.monthlyRadio); break;
        }

        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedRadioId = radioGroup.getCheckedRadioButtonId();
                switch (checkedRadioId) {
                    case R.id.noneRadio: noteDiagFragCommunicator
                            .updateRepetition(0); break;
                    case R.id.dailyRadio: noteDiagFragCommunicator
                            .updateRepetition(1); break;
                    case R.id.weeklyRadio: noteDiagFragCommunicator
                            .updateRepetition(2); break;
                    case R.id.monthlyRadio: noteDiagFragCommunicator
                            .updateRepetition(3); break;
                }
                getFragmentManager().popBackStack();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        ViewGroup.LayoutParams params = getDialog().getWindow().getAttributes();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        getDialog().getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
    }
}
