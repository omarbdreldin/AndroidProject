package com.project.team.triper.fragments;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.project.team.triper.R;
import com.project.team.triper.adaptor.NoteDataAdapter;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.interfaces.NoteDiagFragCommunicator;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TripNoteListDialogFragment extends DialogFragment {

    Trip trip;
    RecyclerView recyclerView;
    NoteDataAdapter adapter;
    Button saveButton;
    ImageButton addNoteButton;
    NoteDiagFragCommunicator noteDiagFragCommunicator;
    EditText newNoteText;

    static TripNoteListDialogFragment newInstance(Trip _trip, NoteDiagFragCommunicator _noteDiagFragCommunicator) {
        TripNoteListDialogFragment f = new TripNoteListDialogFragment();

        Bundle args = new Bundle();
        args.putSerializable("trip", _trip);
        args.putSerializable("parentFrag",_noteDiagFragCommunicator);
        f.setArguments(args);

        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        trip = (Trip) getArguments().getSerializable("trip");
        noteDiagFragCommunicator = (NoteDiagFragCommunicator) getArguments().getSerializable("parentFrag");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_trip_note_list_dialog, container, false);
        saveButton = view.findViewById(R.id.saveButton);
        addNoteButton = view.findViewById(R.id.addNoteButton);
        recyclerView = view.findViewById(R.id.noteListDiag);
        newNoteText = view.findViewById(R.id.newNoteText);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        adapter = new NoteDataAdapter(trip.getNotesAsList(), getContext());
        recyclerView.setAdapter(adapter);

        setControlsListeners();
    }

    private void setControlsListeners() {

        addNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> list = ((NoteDataAdapter) recyclerView.getAdapter()).getNoteList();
                if (!newNoteText.getText().toString().trim().equals("")) {
                    list.add(newNoteText.getText().toString().trim());
                    recyclerView.getAdapter().notifyDataSetChanged();
                    newNoteText.setText("");
                }
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noteDiagFragCommunicator.updateNotes(adapter.getNoteList());
                getFragmentManager().popBackStack();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        ViewGroup.LayoutParams params = getDialog().getWindow().getAttributes();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.MATCH_PARENT;
        getDialog().getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);

    }

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0
            , ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder
                , RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            int swipedPosition = viewHolder.getAdapterPosition();
            adapter.remove(swipedPosition);
        }
    };
}
