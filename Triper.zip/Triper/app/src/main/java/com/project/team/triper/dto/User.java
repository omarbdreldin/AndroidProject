package com.project.team.triper.dto;

import java.io.Serializable;

/**
 * Created by 3alilio on 3/5/2018.
 */

public class User implements Serializable{

     String mail;
     String id;
     String name;

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
