package com.project.team.triper.adaptor;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.project.team.triper.R;

import java.util.ArrayList;

/**
 * Created by Omar on 3/9/2018.
 */

public class NoteDataAdapter extends RecyclerView.Adapter<NoteDataAdapter.ViewHolder> {

    ArrayList<String> noteList;
    Context context;

    public NoteDataAdapter(ArrayList<String> _noteList, Context _context) {
        if (_noteList == null) {
            noteList = new ArrayList<>();
        } else {
            noteList = _noteList;
        }
        context = _context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.note_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.getNoteView().setText(noteList.get(position));
        holder.getNoteView().setFocusableInTouchMode(true);
    }

    public void remove(int id) {
        noteList.remove(id);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView noteView;
        View itemView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            noteView = itemView.findViewById(R.id.noteView);
        }

        public TextView getNoteView() {
            return noteView;
        }

        public View getItemView() {
            return itemView;
        }
    }

    public ArrayList<String> getNoteList() {
        return noteList;
    }
}
