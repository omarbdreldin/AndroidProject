package com.project.team.triper.activities;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.AlarmManagerCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.login.LoginManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.R;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.fragments.FavoraiteFragment;
import com.project.team.triper.fragments.HistoryTripsFragment;
import com.project.team.triper.fragments.NewTripFragment;
import com.project.team.triper.fragments.UpcomingTripsFragment;
import com.project.team.triper.interfaces.FragmentReplacmentInterface;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Permission;
import com.project.team.triper.utilities.Utilities;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, FragmentReplacmentInterface{

    public static final String  UPCOMING = "UPCOMING";
    public static final String  HISTORY = "HISTORY";
    public static final String  NEW = "NEW";
    public static final String  FAVORAITE = "TRIPS HISTORY";
    public static final String  EDIT = "EDIT";
    private String lastTag;
    private FragmentManager fragment_manager;
    private FragmentTransaction fragment_transaction;
    private FrameLayout mainFragment;
    private String mail,name,urlprofile;
    private TextView tv_email,tv_name;
    private User u ;
    private FirebaseUser user;
    private FirebaseAuth mAuth;
    FloatingActionButton fab;
    User user_home;
    ArrayList<Trip> listtrips;
    int flag=0;
    Toolbar toolbar;
    ImageView profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mainFragment  = findViewById(R.id.fmain);
        Utilities.dismissDialog();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        tv_email = (TextView) headerView.findViewById(R.id.tv_email);
        tv_name = (TextView) headerView.findViewById(R.id.tv_name);
        profile = headerView.findViewById(R.id.imageView);
        Intent i = getIntent();

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();

        SharedPreferences Settings = getSharedPreferences("userdata",MODE_PRIVATE);
        mail = Settings.getString("usermail",null);
        name = Settings.getString("username",null);
        urlprofile = Settings.getString("imageurl",null);

        System.out.println(urlprofile);
        if(urlprofile!=null)
        {
            Glide.with(this).load(urlprofile).into(profile);
        } else {
            profile.setImageResource(R.drawable.ic_icon);
        }



        tv_email.setText(mail);
        tv_name.setText(name);
        user_home = new User();
        user_home.setId(Settings.getString("userid",null));
        user_home.setMail(mail);
        user_home.setName(name);


        fragment_manager = getSupportFragmentManager();
        fragment_transaction = fragment_manager.beginTransaction();
        UpcomingTripsFragment frag = new UpcomingTripsFragment();
        frag.setContext(getApplicationContext());
        fragment_transaction.add(R.id.fmain, frag, UPCOMING).commit();
        lastTag = UPCOMING;
        toolbar.setTitle(UPCOMING);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new NewTripFragment(), NEW);
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if(lastTag.equals(UPCOMING))
            {
                super.onBackPressed();
            } else {
                replaceFragment(new UpcomingTripsFragment(), UPCOMING);
            }
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_upcoming) {
            replaceFragment(new UpcomingTripsFragment(), UPCOMING);
        } else if (id == R.id.nav_history) {
            replaceFragment(new HistoryTripsFragment(), HISTORY);
        } else if (id == R.id.nav_Favoraite) {
            replaceFragment(new FavoraiteFragment(), FAVORAITE);
        }
        else if(id == R.id.nav_addnewtrip){
            replaceFragment(new NewTripFragment(), NEW);
        }
        else if (id == R.id.nav_logout)
        {
            LoginManager.getInstance().logOut();
            if(Utilities.isNetworkAvailable(MainActivity.this))
            {
                FirebaseAuth.getInstance().signOut();
            }
            Intent i = new Intent(MainActivity.this,LoginActivity.class);
            SharedPreferences settings = getSharedPreferences("userdata",MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("userid",null);
            editor.putString("usermail",null);
            editor.putString("imageurl",null);
            editor.putString("username",null);
            editor.commit();
            finish();
            startActivity(i);
        } else if (id == R.id.nav_sync){

            // Write a message to the database
            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setTitle("Sync")

                    .setMessage("Are You Sure?")
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialoginterface, int i) {
                            dialoginterface.cancel();
                        }
                    })
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialoginterface, int i) {
                            flag=1;
                            User utem = new User();
                            SharedPreferences Settings = getSharedPreferences("userdata",MODE_PRIVATE);
                            String username = Settings.getString("userid",null);
                            utem.setId(username);

                            if(Utilities.isNetworkAvailable(getApplicationContext())){
                                Utilities.showLoadingDialog(MainActivity.this);
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                final DatabaseReference myRef = database.getReference(username);
                                if(flag==1)
                                {
                                    myRef.addValueEventListener(new ValueEventListener() {

                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            Date current_date = new Date();
                                            GenericTypeIndicator<HashMap<String,Trip>> t = new GenericTypeIndicator<HashMap<String,Trip>>() { };
                                            HashMap<String,Trip> list = (HashMap<String,Trip>) dataSnapshot.child("Trips").getValue(t);
                                            if(list!=null&& list.size()!=0 ){


                                                List<Trip> tripsSQL = new DBAdapter(getApplicationContext()).retrieveAllTripsPerUser(user_home.getMail());
                                                for(Trip temp : tripsSQL)
                                                {
                                                    Utilities.cancelAlarm(getApplicationContext(), temp);
                                                    new DBAdapter(getApplicationContext()).deleteTrip(temp);

                                                }

                                                for(String id : list.keySet())
                                                {
                                                    Trip temp = list.get(id);
                                                    temp.setId(0);
                                                    if(temp.getDate().compareTo(current_date)<0 && temp.getStatus().equals(DBAdapter.STATUS_UPCOMING))
                                                    {
                                                        temp.setStatus(DBAdapter.STATUS_CANCELLED);
                                                    }

                                                    new DBAdapter(getApplicationContext()).addTrip(temp);
                                                }
                                                myRef.child("Trips").setValue(null);
                                                List<Trip> tripsafterSQL = new DBAdapter(getApplicationContext()).retrieveAllTripsPerUser(user_home.getMail());
                                                for(Trip temp: tripsafterSQL)
                                                {
                                                    Utilities.AddtripFB(user_home,temp);
                                                    //Utilities.setAlarm(getApplicationContext(),temp);
                                                    if(temp.getDate().compareTo(current_date)>0)
                                                    {
                                                        Utilities.setAlarm(getApplicationContext(), temp, user_home);
                                                    }
                                                }
                                            }
                                            else if(listtrips!=null&& listtrips.size()==0){
                                                Toast.makeText(MainActivity.this,"No Trips To Show",Toast.LENGTH_SHORT).show();
                                            }
                                            else{
                                            }
                                            myRef.removeEventListener(this);
                                            if(lastTag.equals(UPCOMING))
                                            {
                                                replaceFragment(new UpcomingTripsFragment(),UPCOMING);
                                            }
                                            Utilities.dismissDialog();
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });
                                    flag=0;
                                }

                            }else{
                                Toast.makeText(MainActivity.this,"Please Connect your internet and Try again",Toast.LENGTH_SHORT).show();
                            }


                        }

                    }).show();
        }




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void replaceFragment(Fragment fragment, String tag) {
        toolbar.setTitle(tag);
        if(tag.equals(MainActivity.NEW) | tag.equals(MainActivity.EDIT))
        {
            fab.setVisibility(View.GONE);
        }
        else{
            fab.setVisibility(View.VISIBLE);
        }
        if (tag.equals(MainActivity.UPCOMING)) {
            ((UpcomingTripsFragment)fragment).setContext(getApplicationContext());
        }
        lastTag = tag;
        fragment_manager.beginTransaction().replace(R.id.fmain, fragment, tag).commit();
    }

    public String getMail() {
        return mail;
    }

    public User getUser_home() {
        return user_home;
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Log.v("App","Requesting Permission"+Settings.canDrawOverlays(this));
                /** if not construct intent to request permission**/
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" +getApplicationContext().getPackageName()));
                /* request permission via start activity for result */
                startActivityForResult(intent, 87); //It will call onActivityResult Function After you press Yes/No and go Back after giving permission
            }else{
                Log.v("App","We already have permission for it.");
                // disablePullNotificationTouch();
                //Do your stuff, we got permission captain
            }
        }
    }

    private void setAlarm(Trip t) {
        //getting the alarm manager
        final AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);

        //creating a new intent specifying the broadcast receiver
        final Intent i = new Intent(getApplicationContext(), MyAlarm.class);

        i.putExtra("tripId", t.getId());
        i.putExtra("userId", user_home.getId());
        Utilities.AddtripFB(user_home, t);
        final PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext()
                , new DBAdapter(getApplicationContext()).retrieveLastEntry(), i
                , PendingIntent.FLAG_UPDATE_CURRENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getDate().getTime(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, t.getDate().getTime(), pi);
        }
    }
}
