package com.project.team.triper;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.io.IOException;


public class SoundService extends Service {

    MediaPlayer player;
    AudioManager am;
    int audiotype;
    int userVolume;
    public SoundService() {

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        am= (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);

        audiotype=am.getMode();
        am.setMode(AudioManager.MODE_NORMAL);
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), AudioManager.FLAG_PLAY_SOUND);

        userVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);

        player = new MediaPlayer();
        player.setAudioStreamType(AudioManager.STREAM_ALARM);
        player.setVolume(100,100);
        player.setLooping(true);
        try {
            player.setDataSource(getApplicationContext(), Uri.parse("android.resource://" + "com.project.team.triper" + "/" + R.raw.test));
            player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        player.start();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        am.setStreamVolume(AudioManager.STREAM_ALARM, userVolume, AudioManager.FLAG_PLAY_SOUND);
        player.stop();
        am.setMode(audiotype);
    }


}
