package com.project.team.triper.fragments;


import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.location.places.ui.SupportPlaceAutocompleteFragment;
import com.google.zxing.common.StringUtils;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.adaptor.NoteDataAdapter;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.interfaces.NoteDiagFragCommunicator;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class EditTripFragment extends Fragment implements NoteDiagFragCommunicator {

    transient private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE_START = 1;
    transient private static final int PLACE_AUTOCOMPLETE_REQUEST_CODE_END = 2;
    transient private ImageView tripImageView;
    transient private Trip trip;
    transient private TextView tripNameView;
    transient private Button startPointButton;
    transient private Button endPointButton;
    transient private Button addNoteButton;
    transient private Button dateButton;
    transient private Button timeButton;
    transient private TextView tripTypeView;
    transient private Switch tripTypSwitch;
    transient private Button saveChangesButton;
    //    Button cancelChangesButton;
//    boolean isTripChanged;
//    RecyclerView recyclerView;
//    NoteDataAdapter adapter;
    transient private Calendar calendar;
    transient private Button noteDiag;
    transient private Button repeatDiag;
    transient private User user;
    transient private boolean placeChangedFlag;
    transient private Calendar systemCurrent;

    public EditTripFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit_trip, container, false);
        if (getArguments() != null & getArguments().getSerializable("trip") != null) {
            trip = (Trip) getArguments().getSerializable("trip");
        }

        user = ((MainActivity)getActivity()).getUser_home();

        tripNameView = view.findViewById(R.id.tripNameView);
//        startPointView = (SupportPlaceAutocompleteFragment) getActivity()
//                .getSupportFragmentManager()
//                .findFragmentById(R.id.place_autocomplete_fragment1);
//        if (getActivity()
//                .getSupportFragmentManager()
//                .findFragmentById(R.id.startPointView) == null) {
//            startPointView = new SupportPlaceAutocompleteFragment();
//            startPointView = (SupportPlaceAutocompleteFragment) SupportPlaceAutocompleteFragment
//                    .instantiate(getContext()
//                            , "com.google.android.gms.location.places.ui.SupportPlaceAutocompleteFragment");
//            startPointView = (SupportPlaceAutocompleteFragment) getActivity().getSupportFragmentManager()
//                    .findFragmentById(R.id.startPointView);
//        }

//        if (getActivity()
//                .getSupportFragmentManager()
//                .findFragmentById(R.id.endPointView) == null) {
//            endPointView = new SupportPlaceAutocompleteFragment();
//            endPointView = (SupportPlaceAutocompleteFragment) SupportPlaceAutocompleteFragment
//                    .instantiate(getContext()
//                            , "com.google.android.gms.location.places.ui.SupportPlaceAutocompleteFragment");
//            endPointView = (SupportPlaceAutocompleteFragment) getActivity().getSupportFragmentManager()
//                    .findFragmentById(R.id.endPointView);
//        }

        dateButton = view.findViewById(R.id.dateButton_edit);
        timeButton = view.findViewById(R.id.timeButton_edit);
        tripTypeView = view.findViewById(R.id.tripTypeView_edit);
        tripTypSwitch = view.findViewById(R.id.tripTypeSwitch_edit);
        saveChangesButton = view.findViewById(R.id.saveChangesButton);
//        cancelChangesButton = view.findViewById(R.id.cancelChangesButton);
//        recyclerView = view.findViewById(R.id.noteListView);
        noteDiag = view.findViewById(R.id.notesDiag);
        repeatDiag = view.findViewById(R.id.repeatDiag);
        startPointButton = view.findViewById(R.id.startPointButton_edit);
        endPointButton = view.findViewById(R.id.endPointButton_edit);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        calendar = Calendar.getInstance();
        calendar.setTime(trip.getDate());

        systemCurrent = Calendar.getInstance();
        systemCurrent.setTimeInMillis(System.currentTimeMillis());

        tripNameView.setText(trip.getName());

        if (trip.isType()) {
            tripTypeView.setText("Round Trip");
            tripTypSwitch.setChecked(true);
        } else {
            tripTypeView.setText("One Direction");
            tripTypSwitch.setChecked(false);
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM");
        String dateStr = dateFormat.format(trip.getDate());
        dateButton.setText(dateStr);

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
        String timeStr = timeFormat.format(trip.getDate());
        timeButton.setText(timeStr);

        startPointButton.setText(trip.getStartPoint());
        endPointButton.setText(trip.getEndPoint());

        switch (trip.getRepeat()) {
            case 0:
                repeatDiag.setText("Repetition: None");
                break;
            case 1:
                repeatDiag.setText("Repetition: Daily");
                break;
            case 2:
                repeatDiag.setText("Repetition: Weekly");
                break;
            case 3:
                repeatDiag.setText("Repetition: Monthly");
                break;
        }

//        recyclerView.setHasFixedSize(true);
//        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
//        recyclerView.setLayoutManager(layoutManager);
//
//        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
//        itemTouchHelper.attachToRecyclerView(recyclerView);
//
//        adapter = new NoteDataAdapter(trip.getNotesAsList(), getContext());
//        recyclerView.setAdapter(adapter);
        setControlsListeners();
    }

    @Override
    public void onResume() {
        super.onResume();

//        startPointView.setText(trip.getStartPoint());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            placeChangedFlag = true;
            if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE_START) {
                Place place = PlaceAutocomplete.getPlace(getContext(), data);
                startPointButton.setText(place.getAddress());
                trip.setStartPoint(place.getAddress().toString());
                trip.setStartLongitude(place.getLatLng().longitude);
                trip.setStartLatitude(place.getLatLng().latitude);
            } else if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE_END) {
                Place place = PlaceAutocomplete.getPlace(getContext(), data);
                endPointButton.setText(place.getAddress());
                trip.setEndPoint(place.getAddress().toString());
                trip.setEndLongitude(place.getLatLng().longitude);
                trip.setEndLatitude(place.getLatLng().latitude);
//                trip.setUrl(getContext());
            }
        } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
            Status status = PlaceAutocomplete.getStatus(getContext(), data);
            Log.i("TAG", status.getStatusMessage());
        } else if (resultCode == RESULT_CANCELED) {
            // The user canceled the operation.
        }
    }

    private void setControlsListeners() {

//        addNoteButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                isTripChanged = true;
//                showChangeDetectedButtons();
//                ArrayList<String> list = ((NoteDataAdapter) recyclerView.getAdapter()).getNoteList();
//                if (list.size() == 0) {
//                    list.add("");
//                    recyclerView.getAdapter().notifyDataSetChanged();
//                } else if (!list.get(list.size() - 1).trim().equals("")) {
//                    list.add("");
//                    recyclerView.getAdapter().notifyDataSetChanged();
//                }
//            }
//        });

//        AutocompleteFilter typeFilter = new AutocompleteFilter.Builder()
//                .setCountry("EG").build();

        startPointButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                            .setCountry("EG").build();
                    Intent intent =
                            new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                                    .setFilter(autocompleteFilter).build(getActivity());
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE_START);

                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

//        startPointView.setFilter(typeFilter);
//        startPointView.setOnPlaceSelectedListener(new PlaceSelectionListener() {
//            @Override
//            public void onPlaceSelected(Place place) {
////                showChangeDetectedButtons();
//                startPointView.setText(place.getAddress());
//                trip.setStartPoint(place.getAddress().toString());
//                trip.setStartLongitude(place.getLatLng().longitude);
//                trip.setStartLatitude(place.getLatLng().latitude);
//            }
//
//            @Override
//            public void onError(Status status) {
//            }
//        });

        endPointButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                            .setCountry("EG").build();
                    Intent intent =
                            new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                                    .setFilter(autocompleteFilter).build(getActivity());
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE_END);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

//        endPointView.setFilter(typeFilter);
//        endPointView.setOnPlaceSelectedListener(new PlaceSelectionListener() {
//            @Override
//            public void onPlaceSelected(Place place) {
////                showChangeDetectedButtons();
//                endPointView.setText(place.getAddress());
//                trip.setEndPoint(place.getAddress().toString());
//                trip.setEndLongitude(place.getLatLng().longitude);
//                trip.setEndLatitude(place.getLatLng().latitude);
//                trip.setUrl(getContext());
//                Glide.with(getContext()).load(trip.getMapImageUrl()).into(tripImageView);
//            }
//
//            @Override
//            public void onError(Status status) {
//            }
//        });

        tripTypSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                isTripChanged = true;
//                showChangeDetectedButtons();
                trip.setType(isChecked);
                if (isChecked) {
                    tripTypeView.setText("Round Trip");
                } else {
                    tripTypeView.setText("One Direction");
                }
            }
        });

//        tripNameView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
//                isTripChanged = true;
////                showChangeDetectedButtons();
//                return false;
//            }
//        });

        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeFragment timeFragment = new TimeFragment();
                Bundle args = new Bundle();
                args.putInt("Hour", calendar.get(Calendar.HOUR));
                args.putInt("Minute", calendar.get(Calendar.MINUTE));
                timeFragment.setArguments(args);
                timeFragment.setCallBack(onTimeSetListener);
                timeFragment.show(getActivity().getSupportFragmentManager(), "timePicker");
            }
        });

        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DateFragment dateFragment = new DateFragment();
                Bundle args = new Bundle();
                args.putInt("year", calendar.get(Calendar.YEAR));
                args.putInt("month", calendar.get(Calendar.MONTH));
                args.putInt("day", calendar.get(Calendar.DAY_OF_MONTH));
                dateFragment.setArguments(args);
                dateFragment.setCallBack(onDateSetListener);
                dateFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
            }
        });

        saveChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tripNameView.getText().toString().trim().equals("")) {

                    new AlertDialog.Builder(getContext()).setMessage("Input a trip name!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else if (calendar.compareTo(systemCurrent) <= 0) {

                    new AlertDialog.Builder(getContext()).setMessage("Invalid date!\nInput a future date, please!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else {
                    trip.setDate(new Date(calendar.getTimeInMillis()));
                    trip.setName(tripNameView.getText().toString());
                    Utilities.cancelAlarm(getContext(), trip);
                    Utilities.setAlarm(getContext(), trip, user);
                    if (placeChangedFlag) {
                        Utilities.showLoadingDialog(getContext());
                        new AsyncTask<Trip, Void, Void>() {

                            @Override
                            protected Void doInBackground(Trip... trips) {
                                final Trip trip = trips[0];
                                String polyLinesRequest = "https://maps.googleapis.com/maps/api/directions/json?origin="
                                        + trip.getStartLatitude() + "," + trip.getStartLongitude()
                                        + "&destination=" + trip.getEndLatitude() + "," + trip.getEndLongitude()
                                        + "&key=" + Utilities.DIRECTIONS_API_KEY; System.out.println(polyLinesRequest);
                                RequestQueue queue = Volley.newRequestQueue(getContext());
                                JsonObjectRequest jsonRequest = new JsonObjectRequest(polyLinesRequest, new JSONObject(), new Response.Listener<JSONObject>() {

                                    @Override
                                    public void onResponse(JSONObject response) {
                                        try {
                                            String encodedPolyLines = response.getJSONArray("routes").getJSONObject(0)
                                                    .getJSONObject("overview_polyline").getString("points");

                                            String mapImageUrl = "https://maps.googleapis.com/maps/api/staticmap?size=400x200"

                                                    + "&path=color:0xff0000ff|weight:5|enc:" + encodedPolyLines
                                                    + "&key=" + Utilities.STATIC_MAPS_API_KEY;

                                            String distance = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                                    getJSONObject(0).getJSONObject("distance").getString("text");

                                            String estimatedTime = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                                    getJSONObject(0).getJSONObject("duration").getString("text");

                                            trip.setMapImageUrl(mapImageUrl);
                                            trip.setDistance(distance);
                                            trip.setEstimatedTime(estimatedTime);
                                            new DBAdapter(getContext()).updateTrip(trip);
                                            Utilities.AddtripFB(user, trip);
                                            Utilities.dismissDialog();
                                            ((MainActivity) getActivity())
                                                    .replaceFragment(new UpcomingTripsFragment()
                                                            , MainActivity.UPCOMING);

                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {

                                    @Override
                                    public void onErrorResponse(VolleyError error) {

                                    }
                                });

                                queue.add(jsonRequest);
                                return null;
                            }
                        }.execute(trip);
                    } else {
                        new DBAdapter(getContext()).updateTrip(trip);
                        Utilities.AddtripFB(user, trip);
                        ((MainActivity) getContext()).replaceFragment(new UpcomingTripsFragment(), MainActivity.UPCOMING);
                    }
                }
            }
        });


        noteDiag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TripNoteListDialogFragment tripNoteListDialogFragment = TripNoteListDialogFragment
                        .newInstance(trip, EditTripFragment.this);
                tripNoteListDialogFragment.show(getActivity().getSupportFragmentManager()
                        .beginTransaction().show(tripNoteListDialogFragment)
                        .addToBackStack(null), "noteDiag");
            }
        });

        repeatDiag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RepetitionDialogFragment f = RepetitionDialogFragment.newInstance(trip.getRepeat()
                        , EditTripFragment.this);
                f.show(getActivity().getSupportFragmentManager()
                        .beginTransaction().show(f).addToBackStack(null), "repeatDiag");
            }
        });
    }


    transient private ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0
            , ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder
                , RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
            int swipedPosition = viewHolder.getAdapterPosition();
//            isTripChanged = true;
//            adapter.remove(swipedPosition);
        }
    };

    transient private DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            calendar.set(Calendar.YEAR, year);
            calendar.set(monthOfYear, monthOfYear);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM");
            String dateStr = dateFormat.format(new Date(calendar.getTimeInMillis()));
            dateButton.setText(dateStr);
        }
    };

    transient private TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
            String timeStr = timeFormat.format(new Date(calendar.getTimeInMillis()));
            timeButton.setText(timeStr);
        }
    };

    @Override
    public void updateNotes(ArrayList<String> noteList) {
        trip.setNoteFromArray(noteList);
    }

    @Override
    public void updateRepetition(int _tripRepetition) {
        trip.setRepeat(_tripRepetition);
        switch (_tripRepetition) {
            case 0:
                repeatDiag.setText("Repetition: None");
                break;
            case 1:
                repeatDiag.setText("Repetition: Daily");
                break;
            case 2:
                repeatDiag.setText("Repetition: Weekly");
                break;
            case 3:
                repeatDiag.setText("Repetition: Monthly");
                break;
        }
    }
    private void setAlarm() {
        //getting the alarm manager



        final AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);

        Intent cancelServiceIntent = new Intent(getContext(), MyAlarm.class);
        PendingIntent cancelServicePendingIntent = PendingIntent.getBroadcast(getContext()
                , trip.getId(), cancelServiceIntent
                , PendingIntent.FLAG_UPDATE_CURRENT);
        am.cancel(cancelServicePendingIntent);

        //creating a new intent specifying the broadcast receiver
        final Intent i = new Intent(getContext(), MyAlarm.class);

        i.putExtra("tripId", trip.getId());
        i.putExtra("userId", user.getId());

        final PendingIntent pi = PendingIntent.getBroadcast(getContext()
                , new DBAdapter(getContext()).retrieveLastEntry(), i
                , PendingIntent.FLAG_UPDATE_CURRENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pi);
        }
    }
}
