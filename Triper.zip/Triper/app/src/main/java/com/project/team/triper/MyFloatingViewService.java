package com.project.team.triper;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MyFloatingViewService extends Service {


    private WindowManager windowManager;
    private View collapsedView,floatingView,expandedView;
    int displayWidth,displayHeight;
    ListView notes;
    Button btn_finish;
    Trip trip;
    ImageView img_expanded;
    User user;

    public MyFloatingViewService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        //Inflate the floating view layout we created
        floatingView = LayoutInflater.from(this).inflate(R.layout.floatiny_widget, null);

        collapsedView = floatingView.findViewById(R.id.collapse_view);
        expandedView = floatingView.findViewById(R.id.expanded_view);
        notes =  (ListView)expandedView.findViewById(R.id.list);
        btn_finish = expandedView.findViewById(R.id.btn_finish);
        img_expanded = expandedView.findViewById(R.id.image_expanded);

        img_expanded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                collapsedView.setVisibility(View.VISIBLE);
                expandedView.setVisibility(View.GONE);
            }
        });
        btn_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trip.setStatus(DBAdapter.STATUS_HISTORY);
                new DBAdapter(getApplicationContext()).updateTrip(trip);

                Utilities.AddtripFB(user, trip);
                stopSelf();
            };});

        // Assign adapter to ListView

//        notes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view,
//                                    int position, long id) {
//
//                // ListView Clicked item index
//                int itemPosition     = position;
//
//                // ListView Clicked item value
//                String itemValue    = (String) notes.getItemAtPosition(position);
//
//                // Show Alert
//                Toast.makeText(getApplicationContext(),
//                        "Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG)
//                        .show();

//            }

//        });



//        ImageView closeButtonCollapsed = collapsedView.findViewById(R.id.close_btn);
//
//        closeButtonCollapsed.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                stopSelf();
//            }
//        });

//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
//        WindowManager window = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
//        window.getDefaultDisplay().getMetrics(displayMetrics);
//
//        // The absolute width of the available display size in pixels.
//        int displayWidth = displayMetrics.widthPixels;
//        // The absolute height of the available display size in pixels.
//        int displayHeight = displayMetrics.heightPixels;
//
//        if(lp.height>displayHeight*0.3f)
//        {
//            lp.height=(int)(displayHeight*0.3f);
//        }
//
//        if(lp.width>displayWidth*0.8f)
//        {
//            lp.width=(int)(displayWidth*0.8f);
//        }
//
//
//        expandedView.setLayoutParams(lp);














        DisplayMetrics displayMetrics = new DisplayMetrics();
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        WindowManager window = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        window.getDefaultDisplay().getMetrics(displayMetrics);

        // The absolute width of the available display size in pixels.
        displayWidth = displayMetrics.widthPixels;
        // The absolute height of the available display size in pixels.
        displayHeight = displayMetrics.heightPixels;





        //Add the view to the window.
        int LAYOUT_FLAG;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }

         final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);





        params.gravity = Gravity.TOP | Gravity.LEFT;        //Initially view will be added to top-left corner
        displayWidth = displayMetrics.widthPixels;        //Initially view will be added to top-left corner
        params.x = displayWidth;
        params.y = 100;

        //Add the view to the window
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(floatingView, params);


        //ImageView close_btn_expanding = expandedView.findViewById(R.id.close_button);


//        close_btn_expanding.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                collapsedView.setVisibility(View.VISIBLE);
//                expandedView.setVisibility(View.GONE);
//            }
//        });

        floatingView.findViewById(R.id.rootcontainer).setOnTouchListener(new View.OnTouchListener() {

            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:

                        //remember the initial position.
                        initialX = params.x;
                        initialY = params.y;

                        //get the touch location
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);


                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (Xdiff < 10 && Ydiff < 10) {
                            if (isViewCollapsed()) {
                                //When user clicks on the image view of the collapsed layout,
                                //visibility of the collapsed layout will be changed to "View.GONE"
                                //and expanded view will become visible.
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);


                        //Update the layout with new X & Y coordinate
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });

//        finishTripButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                trip.setStatus(DBAdapter.STATUS_HISTORY);
//                new DBAdapter(getApplicationContext()).updateTrip(trip);
//
//                if (trip.isType()) {
//
//                    String tempPoint = trip.getStartPoint();
//                    trip.setStartPoint(trip.getEndPoint());
//                    trip.setEndPoint(tempPoint);
//
//                    double tempLongitude = trip.getStartLongitude();
//                    double tempLatitude = trip.getStartLatitude();
//                    trip.setStartLongitude(trip.getEndLongitude());
//                    trip.setStartLatitude(trip.getEndLatitude());
//                    trip.setEndLongitude(tempLongitude);
//                    trip.setEndLatitude(tempLatitude);
//
//                    trip.setUrl(getApplicationContext());
//                    trip.setNotes("");
//                    trip.setName(trip.getName() + " (Back Trip)");
//                    trip.setType(false);
//                    trip.setRepeat(0);
//                    trip.setStatus(DBAdapter.STATUS_UPCOMING);
//
//                    new DBAdapter(getApplicationContext()).addTrip(trip);

//                    DialogInterface.OnClickListener onClickListener = new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            if (which == DialogInterface.BUTTON_POSITIVE) {
//                                String tempPoint = trip.getStartPoint();
//                                trip.setStartPoint(trip.getEndPoint());
//                                trip.setEndPoint(tempPoint);
//
//                                double tempLongitude = trip.getStartLongitude();
//                                double tempLatitude = trip.getStartLatitude();
//                                trip.setStartLongitude(trip.getEndLongitude());
//                                trip.setStartLatitude(trip.getEndLatitude());
//                                trip.setEndLongitude(tempLongitude);
//                                trip.setEndLatitude(tempLatitude);
//
//                                trip.setType(false);
//                                trip.setRepeat(0);
//                                trip.setStatus(DBAdapter.STATUS_UPCOMING);
//
//                                new DBAdapter(getApplicationContext()).addTrip(trip);
//                            } else {
//                                dialog.dismiss();
//                            }
//                        }
//                    };
//
//                    new AlertDialog.Builder(getApplicationContext())
//                            .setMessage("This is a round trip.\nDo you want to add the back trip to your list?")
//                            .setPositiveButton("Yes", onClickListener)
//                            .setNegativeButton("No", onClickListener)
//                            .create().show();
//
//                }
//            }
//        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        trip = (Trip) intent.getExtras().getSerializable("trip");
        user = (User) intent.getExtras().getSerializable("user");
        ArrayList<String> notess = new ArrayList<>();

        if(trip.getNotesAsList()==null)
        {
            notess.add("No Notes To show");
//            RelativeLayout.LayoutParams p =
//                    new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
//            notes.setLayoutParams(p);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, android.R.id.text1, notess);
            notes.setAdapter(adapter);

        }else {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, android.R.id.text1, trip.getNotesAsList());

            notes.setAdapter(adapter);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    private boolean isViewCollapsed() {

        return floatingView == null || floatingView.findViewById(R.id.collapse_view).getVisibility() == View.VISIBLE;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(floatingView!=null)
        {
            windowManager.removeView(floatingView);
        }

        if (trip.getStatus().equals(DBAdapter.STATUS_CURRENT)) {
            trip.setStatus(DBAdapter.STATUS_HISTORY);
            Utilities.AddtripFB(user, trip);
            new DBAdapter(getApplicationContext()).updateTrip(trip);
        }

    }

    private void setAlarm(Trip _trip) {
        //getting the alarm manager
        final AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        System.out.println("setting alarm in service------->");
        //creating a new intent specifying the broadcast receiver
        final Intent i = new Intent(getApplicationContext(), MyAlarm.class);

        long time = trip.getDate().getTime();

        i.putExtra("tripId", trip.getId());
        i.putExtra("userId", user.getId());

        Utilities.AddtripFB(user, trip);
        final PendingIntent pi = PendingIntent.getBroadcast(getApplicationContext()
                , trip.getId(), i
                , PendingIntent.FLAG_UPDATE_CURRENT);

        //setting the repeating alarm that will be fired every day
//        am.setRepeating(AlarmManager.RTC_WAKEUP, time, AlarmManager.INTERVAL_DAY, pi);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, time, pi);
        }
    }
}
