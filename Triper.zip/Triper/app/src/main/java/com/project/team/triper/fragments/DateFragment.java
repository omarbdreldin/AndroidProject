package com.project.team.triper.fragments;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

import com.project.team.triper.R;

import java.util.Date;
import java.util.GregorianCalendar;


public class DateFragment extends DialogFragment {
    private DatePicker datePicker;
    DatePickerDialog.OnDateSetListener ondateSet;


    public DateFragment() {
        // Required empty public constructor
    }

    public void setCallBack(DatePickerDialog.OnDateSetListener ondate) {
        ondateSet = ondate;
    }

    private int year, month, day;

    @Override
    public void setArguments(Bundle args) {
        super.setArguments(args);
        year = args.getInt("year");
        month = args.getInt("month");
        day = args.getInt("day");
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){

        View v = LayoutInflater.from(getActivity())
                .inflate(R.layout.fragment_date,null);
        datePicker = (DatePicker) v.findViewById(R.id.datePicker);
        return new DatePickerDialog(getActivity(), ondateSet, year, month, day);

    }

}
