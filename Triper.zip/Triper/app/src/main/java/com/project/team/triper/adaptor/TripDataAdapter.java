package com.project.team.triper.adaptor;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.fragments.EditTripFragment;
import com.project.team.triper.MyFloatingViewService;
import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.fragments.UpcomingDetailDialogFragment;
import com.project.team.triper.fragments.UpcomingTripsFragment;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Omar on 3/4/2018.
 */

public class TripDataAdapter extends RecyclerView.Adapter<TripDataAdapter.ViewHolder>{

    private ArrayList<Trip> tripList;
    Context context;

    public TripDataAdapter(ArrayList<Trip> _tripList, Context _context) {
        tripList = _tripList;
        context = _context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final Trip trip = tripList.get(position);
        holder.getName().setText(trip.getName());

        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM");

        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");


        holder.getStart().setText(trip.getStartPoint());
        holder.getEnd().setText(trip.getEndPoint());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(trip.getDate());
        String element_date =sdf.format(trip.getDate());
        String element_time = timeFormat.format(trip.getDate());

        holder.getDay().setText(element_date);
        holder.getHour().setText(element_time);

        if (trip.isType()) {
            holder.getType().setText("Round Trip");
        } else {
            holder.getType().setText("One Direction");
        }
        holder.getStartTripButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilities.cancelAlarm(context, trip);
                Utilities.checkAndSetRepeat(trip, context, ((MainActivity) context).getUser_home());
                Utilities.startTrip(context, trip, ((MainActivity) context).getUser_home());

            }
        });

        holder.getLinearLayout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpcomingDetailDialogFragment f = UpcomingDetailDialogFragment.newInstance(tripList.get(position));
                f.show(((MainActivity) context).getSupportFragmentManager()
                        .beginTransaction().show(f).addToBackStack(null), "detailDiag");
            }
        });

    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }

    public void remove(int swipedPosition) {
        tripList.remove(swipedPosition);
        notifyDataSetChanged();
    }

    public void add(int swipedPosition, Trip trip) {
        tripList.add(swipedPosition, trip);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name;
        private TextView start;
        private TextView end;
        private TextView day;
        private TextView hour;
        private TextView type;
        private Button startTripButton;
        LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.tripName);
            start = itemView.findViewById(R.id.start);
            end = itemView.findViewById(R.id.end);
            day = itemView.findViewById(R.id.day);
            hour = itemView.findViewById(R.id.hour);
            type = itemView.findViewById(R.id.type);

            startTripButton = itemView.findViewById(R.id.startTripButton);
            linearLayout = itemView.findViewById(R.id.linearLayout);
        }

        public TextView getName() {
            return name;
        }

        public TextView getStart() {
            return start;
        }

        public TextView getEnd() {
            return end;
        }

        public TextView getDay() {
            return day;
        }

        public TextView getHour() {
            return hour;
        }

        public TextView getType() {
            return type;
        }

        public Button getStartTripButton() {
            return startTripButton;
        }

        public LinearLayout getLinearLayout() {
            return linearLayout;
        }
    }

    public ArrayList<Trip> getTripList() {
        return tripList;
    }
}
