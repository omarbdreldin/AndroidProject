package com.project.team.triper.interfaces;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by Omar on 3/6/2018.
 */

public interface FragmentReplacmentInterface {
    void replaceFragment(Fragment fragment, String tag);
}
