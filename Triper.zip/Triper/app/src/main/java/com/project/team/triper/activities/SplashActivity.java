package com.project.team.triper.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.project.team.triper.R;
import com.project.team.triper.utilities.Utilities;

public class SplashActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences Settings = getSharedPreferences("userdata",MODE_PRIVATE);
        String username = Settings.getString("userid",null);
        if(username!=null)
        {

            Intent i = new Intent(SplashActivity.this,MainActivity.class);
            i.putExtra("email",username);
            startActivity(i);
            finish();
        }
        else
        {
            Intent i = new Intent(SplashActivity.this,LoginActivity.class);
            startActivity(i);
            finish();
        }


    }

}
