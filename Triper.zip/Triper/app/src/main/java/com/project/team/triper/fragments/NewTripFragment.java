package com.project.team.triper.fragments;


import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.project.team.triper.MyAlarm;
import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.adaptor.NoteDataAdapter;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.interfaces.NoteDiagFragCommunicator;
import com.project.team.triper.utilities.DBAdapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.AutocompletePrediction;
import com.google.android.gms.location.places.AutocompletePredictionBuffer;
import com.google.android.gms.location.places.Places;
import com.project.team.triper.utilities.Utilities;

import org.json.JSONException;
import org.json.JSONObject;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class NewTripFragment extends Fragment implements NoteDiagFragCommunicator{

    transient private Button createTripButton;
    transient private Button dateButton;
    transient private Button timeButton;
    transient private Calendar calendar;
    transient private static final String DIALOG_DATE = "MainActivity.DateDialog";
    transient private static final String DIALOG_TIME = "MainActivity.TimeDialog";
    transient private Button noteButton;
    transient private EditText tripNameView;
    transient private Button startPointButton;
    transient private Button endPointButton;
    transient private int PLACE_AUTOCOMPLETE_REQUEST_CODE_START = 1;
    transient private int PLACE_AUTOCOMPLETE_REQUEST_CODE_END = 2;
    transient private Trip trip;
    transient private Switch tripTypeSwitch;
    transient private User user;
    transient private Button tripRepetitionButton;
    transient private boolean dateSetFlag;
    transient private boolean timeSetFlag;
    transient private TextView triptypeView;
    transient private Calendar systemCurrent;

    public NewTripFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_trip, container, false);
        createTripButton = view.findViewById(R.id.createTripButton);
        dateButton = view.findViewById(R.id.dateButton);
        timeButton = view.findViewById(R.id.timeButton);
        noteButton = view.findViewById(R.id.notesButton);
        startPointButton = view.findViewById(R.id.start);
        endPointButton = view.findViewById(R.id.end);
        tripTypeSwitch = view.findViewById(R.id.tripTypeSwitch);
        tripNameView = view.findViewById(R.id.tripName);
        tripRepetitionButton = view.findViewById(R.id.tripRepetitionButton);
        triptypeView = view.findViewById(R.id.tripType);
        return view;
    }


    @Override
    public void onStart() {
        super.onStart();

        trip = new Trip();
        calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        systemCurrent = Calendar.getInstance();
        systemCurrent.setTimeInMillis(System.currentTimeMillis());
        user = ((MainActivity) getActivity()).getUser_home();

        triptypeView.setText("One Direction");
        tripRepetitionButton.setText("Repetition");

        startPointButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                            .setCountry("EG").build();
                    Intent intent =
                            new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                                    .setFilter(autocompleteFilter).build(getActivity());
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE_START);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

        endPointButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                            .setCountry("EG").build();
                    Intent intent =
                            new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY)
                                    .setFilter(autocompleteFilter).build(getActivity());
                    startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE_END);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeFragment timeFragment = new TimeFragment();
                Bundle args = new Bundle();
                args.putInt("Hour", calendar.get(Calendar.HOUR));
                args.putInt("Minute", calendar.get(Calendar.MINUTE));
                timeFragment.setArguments(args);
                timeFragment.setCallBack(ontime);
                timeFragment.show(getActivity().getSupportFragmentManager(), "timePicker");
            }
        });

        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DateFragment dateFragment = new DateFragment();
                Bundle args = new Bundle();
                args.putInt("year", calendar.get(Calendar.YEAR));
                args.putInt("month", calendar.get(Calendar.MONTH));
                args.putInt("day", calendar.get(Calendar.DAY_OF_MONTH));
                dateFragment.setArguments(args);
                dateFragment.setCallBack(ondate);
                dateFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
            }
        });

        createTripButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tripNameView.getText().toString().trim().equals("")) {

                    new AlertDialog.Builder(getContext()).setMessage("Input a trip name!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else if (trip.getStartPoint() == null | trip.getEndPoint() == null) {

                    new AlertDialog.Builder(getContext()).setMessage("Input your start and destination!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else if (!dateSetFlag | !timeSetFlag) {

                    new AlertDialog.Builder(getContext()).setMessage("Input date and time of the trip!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else if (calendar.compareTo(systemCurrent) <= 0) {

                    new AlertDialog.Builder(getContext()).setMessage("Invalid date!\nInput a future date, please!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            }).create().show();
                } else {
                    trip.setStatus(DBAdapter.STATUS_UPCOMING);
                    trip.setUser(user.getMail());
                    trip.setName(tripNameView.getText().toString().trim());

                    trip.setDate(new Date(calendar.getTimeInMillis()));

                    Utilities.showLoadingDialog(getContext());
                    new AsyncTask<Trip, Void, Void>() {

                        @Override
                        protected Void doInBackground(Trip... trips) {
                            final Trip trip = trips[0];
                            String polyLinesRequest = "https://maps.googleapis.com/maps/api/directions/json?origin="
                                    + trip.getStartLatitude() + "," + trip.getStartLongitude()
                                    + "&destination=" + trip.getEndLatitude() + "," + trip.getEndLongitude()
                                    + "&key=" + Utilities.DIRECTIONS_API_KEY; System.out.println(polyLinesRequest);
                            RequestQueue queue = Volley.newRequestQueue(getContext());
                            JsonObjectRequest jsonRequest = new JsonObjectRequest(polyLinesRequest, new JSONObject(), new Response.Listener<JSONObject>() {

                                @Override
                                public void onResponse(JSONObject response) {
                                    try {
                                        String encodedPolyLines = response.getJSONArray("routes").getJSONObject(0)
                                                .getJSONObject("overview_polyline").getString("points");

                                        String mapImageUrl = "https://maps.googleapis.com/maps/api/staticmap?size=400x200"

                                                + "&path=color:0xff0000ff|weight:5|enc:" + encodedPolyLines
                                                + "&key=" + Utilities.STATIC_MAPS_API_KEY;

                                        String distance = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                                getJSONObject(0).getJSONObject("distance").getString("text");

                                        String estimatedTime = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                                                getJSONObject(0).getJSONObject("duration").getString("text");

                                        trip.setMapImageUrl(mapImageUrl);
                                        trip.setDistance(distance);
                                        trip.setEstimatedTime(estimatedTime);

                                        new DBAdapter(getContext()).addTrip(trip);
                                        trip.setId(new DBAdapter(getContext()).retrieveLastEntry());
                                        Utilities.setAlarm(getContext(), trip, user);
                                        Utilities.AddtripFB(user, trip);
                                        Utilities.dismissDialog();
                                        ((MainActivity) getActivity())
                                                .replaceFragment(new UpcomingTripsFragment()
                                                        , MainActivity.UPCOMING);

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {

                                }
                            });

                            queue.add(jsonRequest);
                            return null;
                        }
                    }.execute(trip);

                }
            }
        });

        noteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TripNoteListDialogFragment tripNoteListDialogFragment = TripNoteListDialogFragment
                        .newInstance(trip, NewTripFragment.this);
                tripNoteListDialogFragment.show(getActivity().getSupportFragmentManager()
                        .beginTransaction().show(tripNoteListDialogFragment)
                        .addToBackStack(null), "noteDiag");
            }
        });

        tripTypeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                trip.setType(isChecked);
                if (isChecked) {
                    triptypeView.setText("Round Trip");
                } else {
                    triptypeView.setText("One Direction");
                }
            }
        });

        tripRepetitionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RepetitionDialogFragment f = RepetitionDialogFragment.newInstance(trip.getRepeat()
                        , NewTripFragment.this);
                f.show(getActivity().getSupportFragmentManager()
                        .beginTransaction().show(f).addToBackStack(null), "repeatDiag");
            }
        });

        tripRepetitionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RepetitionDialogFragment f = RepetitionDialogFragment.newInstance(trip.getRepeat()
                        , NewTripFragment.this);
                f.show(getActivity().getSupportFragmentManager()
                        .beginTransaction().show(f).addToBackStack(null), "repeatDiag");
            }
        });

    }

    private void setAlarm(final long time) {
        //getting the alarm manager
        final AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);

        //creating a new intent specifying the broadcast receiver
        final Intent i = new Intent(getContext(), MyAlarm.class);

        i.putExtra("tripId", trip.getId());
        i.putExtra("userId", user.getId());

        final PendingIntent pi = PendingIntent.getBroadcast(getContext()
                , new DBAdapter(getContext()).retrieveLastEntry(), i
                , PendingIntent.FLAG_UPDATE_CURRENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pi);
        }
    }


    transient private DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {

            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, monthOfYear);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM");
            String dateStr = dateFormat.format(new Date(calendar.getTimeInMillis()));
            dateButton.setText(dateStr);


            dateSetFlag = true;
        }
    };

    transient private TimePickerDialog.OnTimeSetListener ontime = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
            String timeStr = timeFormat.format(new Date(calendar.getTimeInMillis()));
            timeButton.setText(timeStr);

            timeSetFlag = true;
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE_START) {
                Place place = PlaceAutocomplete.getPlace(getContext(), data);
                startPointButton.setText(place.getAddress());
                trip.setStartPoint(place.getAddress().toString());
                trip.setStartLongitude(place.getLatLng().longitude);
                trip.setStartLatitude(place.getLatLng().latitude);
            } else if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE_END) {
                Place place = PlaceAutocomplete.getPlace(getContext(), data);
                endPointButton.setText(place.getAddress());
                trip.setEndPoint(place.getAddress().toString());
                trip.setEndLongitude(place.getLatLng().longitude);
                trip.setEndLatitude(place.getLatLng().latitude);
//                trip.setUrl(getContext());
            }
        } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
            Status status = PlaceAutocomplete.getStatus(getContext(), data);
            Log.i("TAG", status.getStatusMessage());
        } else if (resultCode == RESULT_CANCELED) {
            // The user canceled the operation.
        }
    }

    @Override
    public void updateNotes(ArrayList<String> noteList) {
        trip.setNoteFromArray(noteList);
    }

    @Override
    public void updateRepetition(int tripRepetition) {
        trip.setRepeat(tripRepetition);
        switch (tripRepetition) {
            case 0: tripRepetitionButton.setText("Repetition: None"); break;
            case 1: tripRepetitionButton.setText("Repetition: Daily"); break;
            case 2: tripRepetitionButton.setText("Repetition: Weekly"); break;
            case 3: tripRepetitionButton.setText("Repetition: Monthly"); break;
        }
    }
}
