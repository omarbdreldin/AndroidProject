package com.project.team.triper.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.utilities.DBAdapter;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FavoraiteFragment extends Fragment {
    ArrayList<Trip> historyTripList;
    int done;
    int upComing;
    int cancelled;
    TextView upcomingnum;
    TextView cancelnum;
    TextView donenum;

    @Override
    public void onStart() {
        super.onStart();

        historyTripList = (ArrayList<Trip>) new DBAdapter(getContext()).retrieveAllTripsPerUser(((MainActivity) getActivity()).getMail());
        for(int i=0;i<historyTripList.size();i++) {
            if (historyTripList.get(i).getStatus().equals(DBAdapter.STATUS_CANCELLED)) {
                cancelled++;
                Log.i("cancelled", String.valueOf(cancelled));
            }

            else if (historyTripList.get(i).getStatus().equals(DBAdapter.STATUS_HISTORY))
            {
                done++;
            Log.i("cancelled2", String.valueOf(done));
             }
            else if (historyTripList.get(i).getStatus().equals(DBAdapter.STATUS_UPCOMING))
            {
                upComing++;
                Log.i("cancelled3", String.valueOf(upComing));
            }
        }
            donenum.setText(String.valueOf(done));
            cancelnum.setText(String.valueOf(cancelled));
            upcomingnum.setText(String.valueOf(upComing));

    }

    public FavoraiteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View favoraite_View=inflater.inflate(R.layout.fragment_favoraite, container, false);
        upcomingnum=favoraite_View.findViewById(R.id.tv_upcomingTrips);
        cancelnum=favoraite_View.findViewById(R.id.tv_canceledTrips);
        donenum=favoraite_View.findViewById(R.id.tv_doneTrips);
        return favoraite_View;
    }

}
