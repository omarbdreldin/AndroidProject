package com.project.team.triper.dto;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.project.team.triper.fragments.UpcomingTripsFragment;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Omar on 3/4/2018.
 */

public class Trip implements Serializable {
    private int id;
    private String name;
    private String user;
    private Calendar calendar;
    private Date date;
    private String startPoint;
    private String endPoint;
    private double startLongitude;
    private double startLatitude;
    private double endLongitude;
    private double endLatitude;
    private boolean type;
    private String status;
    private String notes;
    private int repeat;
    private float duration;
    private float averageSpeed;
    private String mapImageUrl;
    private String distance;
    private String estimatedTime;

    public Trip() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Calendar getCalendar() {
        return calendar;
    }

    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(String startPoint) {
        this.startPoint = startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public double getStartLongitude() {
        return startLongitude;
    }

    public void setStartLongitude(double startLongitude) {
        this.startLongitude = startLongitude;
    }

    public double getStartLatitude() {
        return startLatitude;
    }

    public void setStartLatitude(double startLatitude) {
        this.startLatitude = startLatitude;
    }

    public double getEndLongitude() {
        return endLongitude;
    }

    public void setEndLongitude(double endLongitude) {
        this.endLongitude = endLongitude;
    }

    public double getEndLatitude() {
        return endLatitude;
    }

    public void setEndLatitude(double endLatitude) {
        this.endLatitude = endLatitude;
    }

    public boolean isType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getRepeat() {
        return repeat;
    }

    public void setRepeat(int repeat) {
        this.repeat = repeat;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public float getAverageSpeed() {
        return averageSpeed;
    }

    public void setAverageSpeed(float averageSpeed) {
        this.averageSpeed = averageSpeed;
    }

    public String getMapImageUrl() {
        return mapImageUrl;
    }

    public void setMapImageUrl(String mapImageUrl) {
        this.mapImageUrl = mapImageUrl;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getEstimatedTime() {
        return estimatedTime;
    }

    public void setEstimatedTime(String estimatedTime) {
        this.estimatedTime = estimatedTime;
    }

    public ArrayList<String> getNotesAsList() {
        ArrayList<String> noteList = null;
        if (notes != null) {
            noteList = new ArrayList<String>(Arrays.asList(notes.split("&&&")));
        }
        return noteList;
    }

    public void removeNoteItem(ArrayList<String> noteList) {
        String _notes = "";
        for (String noteItem : noteList) {
            _notes += noteItem;
        }
        notes = _notes;
    }

    public void setNoteFromArray(ArrayList<String> noteList) {
        String _notes = "";
        for (String noteItem : noteList) {
            _notes += (noteItem + "&&&");
        }
        notes = _notes;
    }

    public void setUrl(final Context context) {
        String polyLinesRequest = "https://maps.googleapis.com/maps/api/directions/json?origin="
                + startLatitude + "," + startLongitude
                + "&destination=" + endLatitude + "," + endLongitude
                + "&key=" + Utilities.DIRECTIONS_API_KEY; System.out.println(polyLinesRequest);
        RequestQueue queue = Volley.newRequestQueue(context);
        JsonObjectRequest jsonRequest = new JsonObjectRequest(polyLinesRequest, new JSONObject(), new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    String encodedPolyLines = response.getJSONArray("routes").getJSONObject(0)
                            .getJSONObject("overview_polyline").getString("points");

                    mapImageUrl = "https://maps.googleapis.com/maps/api/staticmap?size=400x200"

                            + "&path=color:0xff0000ff|weight:5|enc:" + encodedPolyLines
                            + "&key=" + Utilities.STATIC_MAPS_API_KEY;

                    distance = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                            getJSONObject(0).getJSONObject("distance").getString("text");

                    estimatedTime = response.getJSONArray("routes").getJSONObject(0).getJSONArray("legs").
                            getJSONObject(0).getJSONObject("duration").getString("text");

                    System.out.println(Trip.this.distance + " " + Trip.this.estimatedTime + "" + mapImageUrl);

                    new DBAdapter(context).updateTrip(Trip.this);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(jsonRequest);
    }


}
