package com.project.team.triper;

/**
 * Created by nourh on 08/03/2018.
 */


import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.bumptech.glide.util.Util;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.util.List;
import java.util.Random;

import static android.content.Context.MODE_PRIVATE;

public class MyAlarm extends BroadcastReceiver {

    Trip trip;
    PendingIntent notification;
    MediaPlayer player;
    Intent mysound;
    User user;
    String sharedUserId;

    @Override
    public void onReceive(final Context context, Intent intent) {
        trip = new DBAdapter(context).retrieveTripById(intent.getIntExtra("tripId", 0));
        String userId = intent.getStringExtra("userId");
        user = new User();
        user.setId(userId);

        System.out.println(context.getPackageName());

        SharedPreferences preferences = context.getSharedPreferences("userdata", MODE_PRIVATE);
        sharedUserId = preferences.getString("userid", null);
        int fromStart = intent.getIntExtra("fromStart", 0);
        int fromEnd = intent.getIntExtra("fromEnd", 0);
        if (fromStart != 0) {
            Utilities.startTrip(context, trip, user);
            trip.setStatus(DBAdapter.STATUS_CURRENT);
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(trip.getId());
            new DBAdapter(context).updateTrip(trip);
        } else if (fromEnd != 0) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(trip.getId());
            trip.setStatus(DBAdapter.STATUS_CANCELLED);
            new DBAdapter(context).updateTrip(trip);
            Utilities.AddtripFB(user, trip);
        } else if (sharedUserId != null) {
            if (user.getId().equals(sharedUserId)) {
                System.out.println(intent.getExtras().getInt("tripId"));
                mysound = new Intent(context, SoundService.class);
                context.startService(mysound);
                Utilities.checkAndSetRepeat(trip, context, user);

                //notification----->
                Intent startIntent = new Intent(context, MyAlarm.class);
                startIntent.putExtra("fromStart", 1);
                startIntent.putExtra("tripId", trip.getId());
                startIntent.putExtra("userId", user.getId());
                PendingIntent startPendingIntent = PendingIntent.getBroadcast(context, new Random().nextInt(150) * 37, startIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                Intent cancelIntent = new Intent(context, MyAlarm.class);
                cancelIntent.putExtra("fromEnd", 2);
                cancelIntent.putExtra("tripId", trip.getId());
                cancelIntent.putExtra("userId", user.getId());
                PendingIntent cancelPendingIntent = PendingIntent.getBroadcast(context, new Random().nextInt(150) * 37, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationChannel channel = null;
                final NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                    channel = new NotificationChannel(String.valueOf(trip.getId())
                            , trip.getName(), NotificationManager.IMPORTANCE_DEFAULT);
                    notificationManager.createNotificationChannel(channel);
                }

                NotificationCompat.Builder mBuilder;

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    mBuilder = new NotificationCompat.Builder(context, channel.getId())
                            .setSmallIcon(R.drawable.ic_icon)
                            .setContentTitle("Upcoming trip: " + trip.getName())
                            .setContentText("What to do?")
                            .addAction(R.drawable.com_facebook_auth_dialog_cancel_background
                                    , "Start", startPendingIntent)
                            .addAction(R.drawable.com_facebook_auth_dialog_cancel_background
                                    , "Cancel", cancelPendingIntent);
                } else {
                    mBuilder = new NotificationCompat.Builder(context)
                            .setSmallIcon(R.drawable.ic_icon)
                            .setContentTitle("Upcoming trip: " + trip.getName())
                            .setContentText("What to do?")
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .addAction(R.drawable.com_facebook_auth_dialog_cancel_background
                                    , "Start", startPendingIntent)
                            .addAction(R.drawable.com_facebook_auth_dialog_cancel_background
                                    , "Cancel", cancelPendingIntent);
                }

                mBuilder.setAutoCancel(false);
                mBuilder.setOngoing(true);

                notificationManager.notify(trip.getId(), mBuilder.build());

                AlertDialog.Builder alertBuild = new AlertDialog.Builder(context);
                alertBuild.setTitle(trip.getName());
                alertBuild.setMessage("Do you want to start the trip now?");

                alertBuild.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        notificationManager.cancel(trip.getId());
                        context.stopService(mysound);

                        trip.setStatus(DBAdapter.STATUS_CANCELLED);
                        new DBAdapter(context).updateTrip(trip);
                        SharedPreferences Settings = context.getSharedPreferences("userdata", MODE_PRIVATE);
                        String mail = Settings.getString("userid", null);
                        Utilities.AddtripFB(user, trip);
                    }
                });

                alertBuild.setNeutralButton(R.string.Later, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        context.stopService(mysound);
                    }
                });

                alertBuild.setPositiveButton("Start", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        notificationManager.cancel(trip.getId());
                        context.stopService(mysound);

                        Utilities.startTrip(context, trip, user);

                        trip.setStatus(DBAdapter.STATUS_CURRENT);
                        new DBAdapter(context).updateTrip(trip);
                    }
                });

                AlertDialog alert = alertBuild.create();
                alert.setCancelable(false);
                alert.setCanceledOnTouchOutside(false);
                alert.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
                alert.show();

            } else {

            }
        }

    }

    public boolean isForeground(Context context){
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List< ActivityManager.RunningTaskInfo > runningTaskInfo = am.getRunningTasks(1);

        ComponentName componentInfo = runningTaskInfo.get(0).topActivity;
        if(componentInfo.getPackageName().equals(context.getPackageName()))
            return true;
        return false;
    }


}
