package com.project.team.triper.interfaces;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Omar on 3/14/2018.
 */

public interface NoteDiagFragCommunicator extends Serializable{
    void updateNotes(ArrayList<String> noteList);
    void updateRepetition(int tripRepetition);
}
