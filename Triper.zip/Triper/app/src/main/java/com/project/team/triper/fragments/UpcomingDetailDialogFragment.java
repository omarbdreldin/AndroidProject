package com.project.team.triper.fragments;


import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.project.team.triper.R;
import com.project.team.triper.activities.MainActivity;
import com.project.team.triper.dto.Trip;
import com.project.team.triper.dto.User;
import com.project.team.triper.interfaces.NoteDiagFragCommunicator;
import com.project.team.triper.utilities.DBAdapter;
import com.project.team.triper.utilities.Utilities;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpcomingDetailDialogFragment extends DialogFragment {
    Trip trip;
    Button editTripButton;
    TextView start;
    TextView end;
    TextView time;
    TextView date;
    TextView name;
    TextView status;
    ListView notes;
    ImageButton imgbtn;
    User user;
    ImageView route;
    Button cancelTrip;

    public static UpcomingDetailDialogFragment newInstance(Trip _trip) {

        UpcomingDetailDialogFragment f = new UpcomingDetailDialogFragment();

        Bundle args = new Bundle();
        args.putSerializable("trip", _trip);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_TITLE, 0);
        trip = (Trip) getArguments().getSerializable("trip");
        user = ((MainActivity) getActivity()).getUser_home();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_detail_dialog, container, false);

        System.out.println("in dialog frag");
        editTripButton = view.findViewById(R.id.editTripButton);
        name=view.findViewById(R.id.tv_tripTitle);
        start=view.findViewById(R.id.tv_startPoint);
        end=view.findViewById(R.id.tv_EndPoint);
        date=view.findViewById(R.id.tv_tripDate);
        time=view.findViewById(R.id.tv_triptime);
        status=view.findViewById(R.id.tv_tripStatus);
        imgbtn = view.findViewById(R.id.img_backarrow_up);
        route = view.findViewById(R.id.img_route_up);
        cancelTrip = view.findViewById(R.id.btn_done);
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });


        Glide.with(getActivity()).load(trip.getMapImageUrl()).into(route);

        name.setText(trip.getName());
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM");
        String dateStr = dateFormat.format(trip.getDate());
        date.setText(dateStr);

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a");
        String timeStr = timeFormat.format(trip.getDate());
        time.setText(timeStr);
        start.setText(trip.getStartPoint());
        end.setText(trip.getEndPoint());
        notes=view.findViewById(R.id.listNotes);
        ArrayList<String> notess = new ArrayList<>();

        if(trip.getNotesAsList()==null)
        {
            notess.add("No Notes To Show");
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1, android.R.id.text1, notess);
            notes.setAdapter(adapter);

        }else {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1, android.R.id.text1, trip.getNotesAsList());
            notes.setAdapter(adapter);
        }

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        setControlsListeners();
    }

    @Override
    public void onResume() {
        super.onResume();

        ViewGroup.LayoutParams params = getDialog().getWindow().getAttributes();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.MATCH_PARENT;
        getDialog().getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
    }

    private void setControlsListeners() {
        editTripButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("trip", trip);
                EditTripFragment editTripFragment = new EditTripFragment();
                editTripFragment.setArguments(bundle);
                getFragmentManager().popBackStack();
                ((MainActivity) getContext()).replaceFragment(editTripFragment, MainActivity.EDIT);
            }
        });

        cancelTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("---------->click");
                Utilities.cancelAlarm(getContext(), trip);
                trip.setStatus(DBAdapter.STATUS_CANCELLED);
                new DBAdapter(getContext()).updateTrip(trip);
                Utilities.AddtripFB(user,trip);
                getFragmentManager().popBackStack();
                UpcomingTripsFragment frag = new UpcomingTripsFragment();
                ((MainActivity) getActivity()).replaceFragment(frag, MainActivity.UPCOMING);
            }
        });
    }
}
